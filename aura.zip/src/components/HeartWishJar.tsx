import React, { useState } from 'react';
import { Heart, RefreshCw, X, Gift } from 'lucide-react';

interface HeartWishJarProps {
  notes: string[];
}

export default function HeartWishJar({ notes }: HeartWishJarProps) {
  const [activeNote, setActiveNote] = useState<string | null>(null);
  const [isShaking, setIsShaking] = useState(false);

  const defaultNotes = [
    "Main ab bhi apna phone check karta hoon ki tumhara message aaya hoga.",
    "Tumhari pyaari hansi is puri galaxy ka mera sabse pasandida music track hai.",
    "Mujhe bahut pasand hai jab hum dono hamesha exact ek hi word sath bolte hain.",
    "Tumhara haath pakadna hamesha mujhe sukoon deta hai jab life pareshan karti hai.",
    "Tum ek simple Ramen date ko bhi ek bahut pyari indie movie scene bana deti ho.",
    "Happy Birthday, meri pyari star. Ye universe sach mein blessed hai ki tum isme ho."
  ];

  const actualNotes = notes && notes.length > 0 ? notes : defaultNotes;

  const drawNote = () => {
    if (isShaking) return;
    setIsShaking(true);
    
    // Play sweet shaking physical impact delay
    setTimeout(() => {
      const randomIdx = Math.floor(Math.random() * actualNotes.length);
      setActiveNote(actualNotes[randomIdx]);
      setIsShaking(false);
    }, 700);
  };

  return (
    <div id="heart-wish-jar-frame" className="bg-dark-card backdrop-blur-md rounded-2xl p-6 border border-white/5 shadow-2xl max-w-sm w-full mx-auto text-center relative overflow-hidden">
      
      {/* Absolute gold sparkles header */}
      <div className="absolute inset-x-0 top-0 h-10 bg-gradient-to-b from-gold/5 to-transparent pointer-events-none" />

      <h3 className="font-serif font-medium text-lg text-warm-white mb-1.5 flex items-center justify-center gap-1.5">
        💌 Dil Ki Baatein (Confession Jar)
      </h3>
      <p className="text-xs text-warm-gray mb-6">Jar ko shake karke ek pyaara sa secret paper message nikaalein!</p>

      {/* Interactive Glass Bottle representation */}
      <div className="relative my-6 flex justify-center">
        <button
          id="confession-jar-bottle"
          onClick={drawNote}
          className={`relative w-40 h-48 focus:outline-none transition-transform duration-300 ${isShaking ? 'animate-wiggle' : 'hover:scale-105 active:scale-95 cursor-pointer'}`}
        >
          {/* Amber apothecary bottle styling */}
          <div className="absolute inset-0 bg-gradient-to-tr from-gold/15 to-[#2a1a1a]/80 border-2 border-gold/40 rounded-[36px] rounded-t-2xl flex flex-col items-center pt-8 shadow-inner overflow-hidden">
            {/* Liquid / Heart items sitting inside */}
            <div className="absolute bottom-4 inset-x-4 h-16 bg-gold/5 rounded-full blur-[10px] pointer-events-none" />
            
            {/* Little hearts floating in bottle */}
            <div className="flex flex-wrap gap-2 justify-center max-w-[80px]">
              <Heart className="w-5 h-5 text-gold fill-gold/30 animate-pulse pointer-events-none" />
              <Heart className="w-4 h-4 text-rose-500 fill-rose-500/20 pointer-events-none duration-1000 animate-bounce" />
              <Heart className="w-5 h-5 text-amber-500 fill-amber-500/20 pointer-events-none duration-700 animate-bounce" />
              <Heart className="w-4 h-4 text-gold fill-gold/45 pointer-events-none animate-ping" />
            </div>

            {/* Visual parchment inside */}
            <div className="mt-4 bg-[#1e1717] border border-gold/30 text-[9px] px-2 py-1 rounded shadow-sm rotate-6 font-mono text-gold pointer-events-none uppercase tracking-wider">
              PYAAR KA NOTE
            </div>
          </div>

          {/* Jar cap */}
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-16 h-4 bg-gold rounded-md border border-gold/80" />
        </button>
      </div>

      <button
        id="shake-draw-button"
        onClick={drawNote}
        disabled={isShaking}
        className="px-5 py-2 rounded-full border border-gold/25 bg-gold/5 hover:bg-gold/10 text-xs font-semibold flex items-center gap-1.5 mx-auto transition-all text-gold cursor-pointer shadow-sm"
      >
        <RefreshCw className={`w-3.5 h-3.5 ${isShaking ? 'animate-spin' : ''}`} />
        {isShaking ? 'Jar hil raha hai...' : 'Message Nikalo'}
      </button>

      {/* Pop up envelope card */}
      {activeNote !== null && (
        <div id="envelope-folded-paper" className="fixed inset-0 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-fade-in">
          <div className="bg-[#120d0d] text-warm-white border border-gold/30 p-6 md:p-8 rounded-2xl max-w-sm w-full shadow-2xl relative text-center">
            
            <button
              id="close-folded-paper"
              onClick={() => setActiveNote(null)}
              className="absolute top-3 right-3 text-warm-gray hover:text-gold transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Cute heart seal symbol */}
            <div className="w-10 h-10 bg-gold/10 border border-gold/20 rounded-full flex items-center justify-center mx-auto mb-4 scale-110">
              <Gift className="w-5 h-5 text-gold" />
            </div>

            <span className="text-[10px] font-mono tracking-widest text-gold uppercase font-bold block mb-3">
              Aapke Liye Pyaara Message
            </span>

            {/* Secret confession message */}
            <div className="relative font-serif text-base leading-relaxed italic text-[#f4efe8] py-4 border-y border-white/5">
              "{activeNote}"
            </div>

            <p className="text-[10px] font-sans text-warm-gray mt-4 italic block">
              "Ek aur pyaara message nikalne ke liye fir se shake karein."
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
