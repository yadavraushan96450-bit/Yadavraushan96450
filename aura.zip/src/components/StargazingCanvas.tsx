import React, { useEffect, useRef, useState } from 'react';
import { Shovel, Star, Moon, RefreshCw, X } from 'lucide-react';

interface StargazingCanvasProps {
  wishes: string[];
}

interface StarNode {
  x: number;
  y: number;
  size: number;
  speedY: number;
  speedX: number;
  alpha: number;
  pulseSpeed: number;
  isWish: boolean;
  wishIdx?: number;
  glowColor: string;
}

export default function StargazingCanvas({ wishes }: StargazingCanvasProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const starsRef = useRef<StarNode[]>([]);
  const animationFrameRef = useRef<number | null>(null);

  const [activeWishText, setActiveWishText] = useState<string | null>(null);
  const [activeWishIdx, setActiveWishIdx] = useState<number | null>(null);

  // Default romantic wishes if none custom-provided
  const defaultWishes = [
    "Sath mein ek pyara sa ghar banana, jahan hum baarish ke din sath baith ke chai piyein.",
    "Tumhari in pyaari aur chamakti aankhon ki haseen chamak hamesha aise hi barkarar rahe.",
    "Dher saara safar karna, ek doosre ka haath pakadna, aur haseen candle-light dinners.",
    "Tum jab bhi subah utho, tumhare dil ko pata ho ki tumse beintehaa pyaar kiya jata hai.",
    "Jab pure jahan mein shor ho, main tumhare liye sakoon ka wo ek kona banu."
  ];

  const actualWishes = wishes && wishes.length > 0 ? wishes : defaultWishes;

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Set up canvas sizing via ResizeObserver to meet responsive guidelines
    const resizeObserver = new ResizeObserver((entries) => {
      for (let entry of entries) {
        const { width, height } = entry.contentRect;
        canvas.width = width;
        canvas.height = height;

        // Initialize stars nicely based on new size
        initStars(width, height);
      }
    });

    if (containerRef.current) {
      resizeObserver.observe(containerRef.current);
    }

    const initStars = (w: number, h: number) => {
      const starArray: StarNode[] = [];
      const density = Math.min(100, Math.floor((w * h) / 8000));

      // Regular stars
      for (let i = 0; i < density; i++) {
        starArray.push({
          x: Math.random() * w,
          y: Math.random() * h,
          size: Math.random() * 1.5 + 0.5,
          speedY: (Math.random() - 0.5) * 0.15,
          speedX: (Math.random() - 0.5) * 0.15,
          alpha: Math.random() * 0.6 + 0.2,
          pulseSpeed: Math.random() * 0.02 + 0.005,
          isWish: false,
          glowColor: '255, 255, 255'
        });
      }

      // Special interactive wishing stars
      for (let i = 0; i < actualWishes.length; i++) {
        starArray.push({
          x: Math.random() * (w - 100) + 50,
          y: Math.random() * (h - 150) + 50,
          size: Math.random() * 4 + 3, // slightly bigger wishing lanterns
          speedY: (Math.random() - 0.5) * 0.1,
          speedX: (Math.random() - 0.5) * 0.1,
          alpha: 1.0,
          pulseSpeed: Math.random() * 0.04 + 0.02,
          isWish: true,
          wishIdx: i,
          glowColor: i % 2 === 0 ? '201, 160, 80' : '255, 230, 180' // Gold and Champagne glowing stars
        });
      }

      starsRef.current = starArray;
    };

    const draw = () => {
      if (!ctx || !canvas) return;

      // Dark celestial backdrop
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      const gradient = ctx.createLinearGradient(0, 0, 0, canvas.height);
      gradient.addColorStop(0, '#090707'); // Dark slate-charcoal
      gradient.addColorStop(0.5, '#120d0d'); // Sophisticated Dark standard
      gradient.addColorStop(1, '#1c1515'); // Custom warm gradient
      ctx.fillStyle = gradient;
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      const stars = starsRef.current;
      for (let s of stars) {
        // Move stars gently
        s.y += s.speedY;
        s.x += s.speedX;

        // Bounce back inside boundaries
        if (s.y < 0 || s.y > canvas.height) s.speedY = -s.speedY;
        if (s.x < 0 || s.x > canvas.width) s.speedX = -s.speedX;

        // Pulse opacity
        s.alpha += s.pulseSpeed;
        if (s.alpha > 1 || s.alpha < 0.15) {
          s.pulseSpeed = -s.pulseSpeed;
        }

        // Draw star
        ctx.save();
        ctx.beginPath();
        ctx.arc(s.x, s.y, s.size, 0, Math.PI * 2);

        if (s.isWish) {
          // Glow shadow for wishing stars
          ctx.shadowBlur = s.size * 3;
          ctx.shadowColor = `rgba(${s.glowColor}, ${s.alpha})`;
          ctx.fillStyle = `rgba(${s.glowColor}, ${Math.max(0.4, s.alpha)})`;
        } else {
          ctx.fillStyle = `rgba(${s.glowColor}, ${s.alpha})`;
        }

        ctx.fill();
        ctx.restore();
      }

      animationFrameRef.current = requestAnimationFrame(draw);
    };

    draw();

    // Cleanups
    return () => {
      resizeObserver.disconnect();
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, [actualWishes]);

  // Click handler to catch on-canvas wishing star clicks
  const handleCanvasClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const clickY = e.clientY - rect.top;

    // Detect if we clicked any wishing star (with tolerance)
    const tolerance = 22;
    const clickedWishStar = starsRef.current.find(s => {
      if (!s.isWish) return false;
      const dist = Math.sqrt((s.x - clickX) ** 2 + (s.y - clickY) ** 2);
      return dist <= tolerance;
    });

    if (clickedWishStar && clickedWishStar.wishIdx !== undefined) {
      setActiveWishIdx(clickedWishStar.wishIdx);
      setActiveWishText(actualWishes[clickedWishStar.wishIdx]);
    }
  };

  return (
    <div id="canvas-stargazing-frame" className="relative w-full rounded-2xl overflow-hidden shadow-2xl border border-white/5" style={{ height: '380px' }} ref={containerRef}>
      <canvas
        ref={canvasRef}
        onClick={handleCanvasClick}
        className="block cursor-pointer"
      />

      {/* Instruction overlay */}
      <div className="absolute top-4 left-4 bg-[#120d0d]/90 backdrop-blur-md px-3.5 py-1.5 rounded-xl border border-gold/20 text-[10px] font-mono tracking-wider uppercase text-warm-white pointer-events-none flex items-center gap-2">
        <span className="w-2.5 h-2.5 bg-gold rounded-full animate-ping" />
        <span>Timtimate sunehre taron par click karke hamari wishes dekhein! 🌟</span>
      </div>

      {/* Floating Wish Modal */}
      {activeWishText !== null && (
        <div id="star-wish-pouch" className="absolute inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 z-20">
          <div className="bg-[#120d0d] border border-gold/30 p-6 rounded-2xl max-w-sm w-full shadow-2xl text-center relative animate-fade-in">
            <button
              id="close-wish-modal"
              onClick={() => {
                setActiveWishText(null);
                setActiveWishIdx(null);
              }}
              className="absolute top-3 right-3 text-warm-gray hover:text-gold transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="w-12 h-12 bg-gold/10 text-gold border border-gold/20 rounded-full flex items-center justify-center mx-auto mb-4 animate-pulse">
              <Star className="w-6 h-6 fill-gold/20" />
            </div>

            <span className="text-[10px] font-mono font-bold tracking-widest text-[#c9a050] uppercase">
              Hamari Sunehri Wish #{activeWishIdx !== null ? activeWishIdx + 1 : 1}
            </span>

            <h5 className="font-serif font-medium text-lg text-warm-white mt-2 leading-relaxed italic">
              "{activeWishText}"
            </h5>

            <p className="text-[11px] text-gold/80 mt-4 font-serif">
              "Zameen se aasmaan tak, hamara ye pyaar hamesha amar rahega."
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
