import React, { useState } from 'react';
import { QuizQuestion } from '../types';
import { Sparkles, Trophy, Heart, ArrowRight, RotateCcw, AlertCircle } from 'lucide-react';

interface InteractiveQuizProps {
  questions: QuizQuestion[];
  partnerName: string;
}

export default function InteractiveQuiz({ questions, partnerName }: InteractiveQuizProps) {
  const [currentIdx, setCurrentIdx] = useState(0);
  const [selectedOpt, setSelectedOpt] = useState<number | null>(null);
  const [isAnswered, setIsAnswered] = useState(false);
  const [score, setScore] = useState(0);
  const [quizCompleted, setQuizCompleted] = useState(false);
  const [showHearts, setShowHearts] = useState<boolean>(false);

  if (!questions || questions.length === 0) {
    return (
      <div className="bg-dark-card p-6 rounded-2xl border border-white/5 text-center text-sm text-warm-gray">
        <AlertCircle className="w-8 h-8 text-gold mx-auto mb-2" />
        Abhi tak koi quiz questions set nahi hain. Customization panel mein jaakar pyaare questions likhein!
      </div>
    );
  }

  const currentQuestion = questions[currentIdx];

  const handleOptionClick = (optionIdx: number) => {
    if (isAnswered) return;
    setSelectedOpt(optionIdx);
    setIsAnswered(true);

    const isCorrect = optionIdx === currentQuestion.correctAnswerIndex;
    if (isCorrect) {
      setScore(prev => prev + 1);
      setShowHearts(true);
      setTimeout(() => setShowHearts(false), 2500);
    }
  };

  const handleNext = () => {
    setSelectedOpt(null);
    setIsAnswered(false);
    if (currentIdx < questions.length - 1) {
      setCurrentIdx(prev => prev + 1);
    } else {
      setQuizCompleted(true);
    }
  };

  const restartQuiz = () => {
    setCurrentIdx(0);
    setSelectedOpt(null);
    setIsAnswered(false);
    setScore(0);
    setQuizCompleted(false);
  };

  return (
    <div id="interactive-quiz-container" className="bg-dark-card backdrop-blur-md rounded-2xl shadow-2xl border border-white/5 p-6 md:p-8 max-w-xl w-full mx-auto relative overflow-hidden transition-all">
      {/* Decorative Hearts flying up */}
      {showHearts && (
        <div className="absolute inset-0 pointer-events-none flex items-center justify-center z-50">
          <div className="text-3xl animate-bounce flex gap-2">
            <span className="animate-ping">❤️</span>
            <span className="scale-125">💖</span>
            <span className="animate-ping">💕</span>
            <span>💝</span>
          </div>
        </div>
      )}

      {/* Header */}
      <div className="flex items-center justify-between border-b border-white/5 pb-4 mb-6">
        <div>
          <h3 className="font-serif font-medium text-lg text-warm-white flex items-center gap-1.5">
            <Heart className="w-4 h-4 text-gold fill-gold" />
            {partnerName || 'Pyaar'} Ke Liye Surprise Quiz
          </h3>
          <p className="text-xs text-warm-gray">Hamari yaadon ka ek pyaara sa test</p>
        </div>
        {!quizCompleted && (
          <span className="text-xs font-mono font-bold bg-gold/10 border border-gold/20 text-gold px-3 py-1 rounded-full">
            Sawal {currentIdx + 1} of {questions.length}
          </span>
        )}
      </div>

      {!quizCompleted ? (
        <div id="quiz-question-box">
          {/* Question Text */}
          <h4 className="font-serif font-medium text-xl text-warm-white mb-6 leading-relaxed">
            "{currentQuestion.question}"
          </h4>

          {/* Options List */}
          <div className="space-y-3 mb-6">
            {currentQuestion.options.map((option, optIdx) => {
              // Styling helper logic
              let optStyle = 'border-white/5 bg-zinc-950 text-warm-white hover:bg-white/5 hover:border-gold/30 hover:text-gold';
              if (isAnswered) {
                if (optIdx === currentQuestion.correctAnswerIndex) {
                  optStyle = 'border-emerald-500 bg-emerald-950/20 text-emerald-300 font-bold';
                } else if (optIdx === selectedOpt) {
                  optStyle = 'border-rose-950 bg-rose-950/20 text-rose-300';
                } else {
                  optStyle = 'border-white/5 bg-zinc-950/40 text-warm-gray opacity-40';
                }
              }

              return (
                <button
                  key={optIdx}
                  id={`quiz-option-${optIdx}`}
                  onClick={() => handleOptionClick(optIdx)}
                  disabled={isAnswered}
                  className={`w-full p-4 rounded-xl text-left text-sm border font-medium transition-all duration-200 outline-none flex items-center justify-between cursor-pointer ${optStyle}`}
                >
                  <span>{option}</span>
                  {isAnswered && optIdx === currentQuestion.correctAnswerIndex && (
                    <Sparkles className="w-4 h-4 text-emerald-500" />
                  )}
                  {isAnswered && optIdx === selectedOpt && optIdx !== currentQuestion.correctAnswerIndex && (
                    <AlertCircle className="w-4 h-4 text-rose-500" />
                  )}
                </button>
              );
            })}
          </div>

          {/* Answer details note */}
          {isAnswered && (
            <div
              id="quiz-explanation-pouch"
              className={`p-4 rounded-xl mb-6 text-sm border leading-relaxed animate-fade-in ${
                selectedOpt === currentQuestion.correctAnswerIndex
                  ? 'bg-emerald-950/10 border-emerald-900/40 text-emerald-400'
                  : 'bg-rose-950/10 border-rose-900/40 text-rose-450'
              }`}
            >
              <strong>{selectedOpt === currentQuestion.correctAnswerIndex ? 'Sahi Jawab! ✨ ' : 'Oops! ❤️ '}</strong>
              {selectedOpt === currentQuestion.correctAnswerIndex 
                ? currentQuestion.messageIfCorrect 
                : currentQuestion.messageIfWrong}
            </div>
          )}

          {/* Action Trigger */}
          {isAnswered && (
            <button
              id="quiz-next-btn"
              onClick={handleNext}
              className="w-full py-3 bg-gold text-dark-bg rounded-xl font-bold text-xs flex items-center justify-center gap-2 hover:bg-gold/90 transition-all shadow-md hover:scale-[1.02] active:scale-[0.98] cursor-pointer tracking-widest uppercase"
            >
              <span>{currentIdx === questions.length - 1 ? 'Quiz poora karein' : 'Agle sawal par chalein'}</span>
              <ArrowRight className="w-4 h-4 text-dark-bg" />
            </button>
          )}
        </div>
      ) : (
        /* Completed Score Screen */
        <div id="quiz-finished-card" className="text-center py-6">
          <div className="w-20 h-20 bg-gold/10 border border-gold/20 rounded-full flex items-center justify-center mx-auto mb-4 animate-pulse">
            <Trophy className="w-10 h-10 text-gold" />
          </div>
          <h4 className="font-serif font-medium text-2xl text-warm-white mb-2">Quiz Poora Hua!</h4>
          <p className="text-warm-gray text-sm max-w-sm mx-auto mb-6">
            Aapka score hai <span className="font-bold text-gold text-lg">{score}</span> out of <span className="font-bold text-warm-white">{questions.length}</span>!
          </p>

          <div className="bg-gold/5 border border-gold/10 p-5 rounded-2xl max-w-sm mx-auto mb-6 text-xs leading-relaxed text-warm-gray text-left">
            {score === questions.length ? (
              <p>🥇 "Sache Premi! Tumhe hamari ek-ek baat yaad hai! Mera dil hamesha tumhare paas hi rahega aur dharakta rahega."</p>
            ) : score >= questions.length / 2 ? (
              <p>🥈 "So sweet! Tum hamare baare mein bahut acche se jaante ho! Agli cozy chocolate-laden date par bachi hui baatein sath baith ke discuss karenge."</p>
            ) : (
              <p>❤️ "Sath mein guzaara har naya din hume ek doosre ke kareeb lata hai. Chalo, ek doosre ka haath pakadte hain aur sath isey fir se padhte hain!"</p>
            )}
          </div>

          <div className="flex gap-3 justify-center">
            <button
              id="quiz-restart-btn"
              onClick={restartQuiz}
              className="py-2.5 px-5 rounded-xl border border-gold/25 bg-gold/5 hover:bg-gold/10 text-xs font-bold flex items-center gap-1.5 transition-all text-gold cursor-pointer uppercase tracking-wider"
            >
              <RotateCcw className="w-3.5 h-3.5 text-gold" />
              Fir se Koshish Karo
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
