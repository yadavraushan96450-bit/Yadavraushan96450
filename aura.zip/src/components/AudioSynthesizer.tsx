import React, { useState, useEffect, useRef } from 'react';
import { Music, Play, Pause, Volume2, Sparkles, VolumeX } from 'lucide-react';

interface Preset {
  name: string;
  notes: number[]; // frequencies
  interval: number; // millisecond intervals
  waveType: OscillatorType;
}

const TUNES: Record<string, Preset> = {
  rose: {
    name: "Gulabon Ki Taal (Pyari Lullaby)",
    notes: [261.63, 329.63, 392.00, 523.25, 349.23, 440.00, 523.25, 587.33, 293.66, 349.23, 440.00, 523.25], // C Major & F major chords
    interval: 800,
    waveType: "triangle"
  },
  celestial: {
    name: "Sitaron Ke Sapne (Pyari Bells)",
    notes: [329.63, 392.00, 493.88, 587.33, 659.25, 783.99, 987.77], // E Minor Pentatonic scale - beautiful stargazing sound
    interval: 1200,
    waveType: "sine"
  },
  vintage: {
    name: "Purane Din (Retro Celeste)",
    notes: [293.66, 392.00, 440.00, 493.88, 587.33, 659.25, 783.99], // G Major - bright and retro emotional
    interval: 600,
    waveType: "triangle"
  }
};

export default function AudioSynthesizer() {
  const [isPlaying, setIsPlaying] = useState(false);
  const [activeTune, setActiveTune] = useState<keyof typeof TUNES>("rose");
  const [volume, setVolume] = useState(0.4);
  const [tempo, setTempo] = useState(1); // multiplier
  const [activeNoteIdx, setActiveNoteIdx] = useState<number | null>(null);

  const audioCtxRef = useRef<AudioContext | null>(null);
  const playSeqTimeoutRef = useRef<number | null>(null);
  const gainNodeRef = useRef<GainNode | null>(null);
  const noteIndexRef = useRef(0);

  // Initialize Audio Context lazily
  const initAudio = () => {
    if (!audioCtxRef.current) {
      audioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
    if (audioCtxRef.current.state === 'suspended') {
      audioCtxRef.current.resume();
    }
  };

  const playCustomNote = (frequency: number) => {
    if (!audioCtxRef.current) return;
    try {
      const ctx = audioCtxRef.current;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.connect(gain);
      gain.connect(ctx.destination);

      const targetTune = TUNES[activeTune];
      osc.type = targetTune.waveType;
      osc.frequency.setValueAtTime(frequency, ctx.currentTime);

      // Sweet physical modeling wrap - Attack-Decay envelope for warm bells instead of harsh beep
      const attack = 0.08;
      const decay = 1.4;
      
      gain.gain.setValueAtTime(0, ctx.currentTime);
      gain.gain.linearRampToValueAtTime(volume, ctx.currentTime + attack);
      gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + attack + decay);

      osc.start(ctx.currentTime);
      osc.stop(ctx.currentTime + attack + decay + 0.1);
    } catch (e) {
      console.error("Synth Playback error:", e);
    }
  };

  const togglePlayback = () => {
    initAudio();
    setIsPlaying(!isPlaying);
  };

  // Playback sequence loop
  useEffect(() => {
    if (!isPlaying) {
      if (playSeqTimeoutRef.current) {
        clearTimeout(playSeqTimeoutRef.current);
        playSeqTimeoutRef.current = null;
      }
      setActiveNoteIdx(null);
      return;
    }

    const currentTune = TUNES[activeTune];
    
    const playNext = () => {
      const idx = noteIndexRef.current % currentTune.notes.length;
      setActiveNoteIdx(idx);
      playCustomNote(currentTune.notes[idx]);
      
      noteIndexRef.current += 1;
      const nextTime = currentTune.interval / tempo;
      
      playSeqTimeoutRef.current = window.setTimeout(playNext, nextTime);
    };

    playNext();

    return () => {
      if (playSeqTimeoutRef.current) {
        clearTimeout(playSeqTimeoutRef.current);
      }
    };
  }, [isPlaying, activeTune, volume, tempo]);

  return (
    <div id="audio-synthesizer-card" className="bg-dark-card backdrop-blur-md rounded-2xl p-6 border border-white/5 shadow-2xl max-w-md w-full mx-auto relative overflow-hidden">
      <div className="absolute top-0 right-0 w-32 h-32 bg-gold/5 rounded-full blur-2xl pointer-events-none" />

      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className={`p-2.5 rounded-xl border ${isPlaying ? 'bg-[#1a1212] text-gold border-gold/20 animate-spin-slow' : 'bg-[#110d0d] text-warm-gray border-white/5'}`}>
            <Music className="w-5 h-5" id="audio-synth-icon" />
          </div>
          <div>
            <h3 className="font-serif font-medium text-lg text-warm-white flex items-center gap-1.5">
              Pyari Chime Box 🎵
              {isPlaying && <Sparkles className="w-4 h-4 text-gold animate-pulse" />}
            </h3>
            <p className="text-xs text-warm-gray">Apna background music chalu karein</p>
          </div>
        </div>
        <button
          id="music-box-power"
          onClick={togglePlayback}
          className={`px-4 py-2 rounded-full font-semibold text-xs tracking-wider uppercase transition-all flex items-center gap-1.5 shadow-sm hover:scale-105 active:scale-95 cursor-pointer ${
            isPlaying 
              ? 'bg-gold text-dark-bg' 
              : 'bg-[#1a1212] text-gold border border-gold/20 hover:bg-[#221818]'
          }`}
        >
          {isPlaying ? (
            <>
              <Pause className="w-3.5 h-3.5" />
              Baj raha hai
            </>
          ) : (
            <>
              <Play className="w-3.5 h-3.5" />
              Play Karo
            </>
          )}
        </button>
      </div>

      <div className="space-y-4">
        {/* Melody Track Picker */}
        <div>
          <label className="text-[10px] font-mono tracking-widest uppercase text-warm-gray block mb-2">Music Theme Select Karo</label>
          <div className="grid grid-cols-3 gap-2">
            {(Object.keys(TUNES) as Array<keyof typeof TUNES>).map((key) => (
              <button
                key={key}
                id={`synth-theme-${key}`}
                onClick={() => {
                  initAudio();
                  setActiveTune(key);
                  noteIndexRef.current = 0;
                }}
                className={`py-2 px-2 text-[11px] rounded-lg border text-center transition-all truncate font-serif cursor-pointer ${
                  activeTune === key
                    ? 'border-gold/30 bg-gold/5 text-gold font-bold'
                    : 'border-white/5 bg-zinc-950/40 text-warm-gray hover:text-gold hover:bg-white/5'
                }`}
              >
                {TUNES[key].name.split(" ")[0]}
              </button>
            ))}
          </div>
        </div>

        {/* Floating Note Visualizer */}
        <div className="h-12 bg-zinc-950/50 rounded-xl flex items-center justify-center gap-2 px-3 border border-white/5 overflow-hidden">
          {TUNES[activeTune].notes.map((freq, idx) => (
            <div
              key={idx}
              id={`waveform-bar-${idx}`}
              style={{
                height: isPlaying && activeNoteIdx === idx ? `${Math.min(freq / 12, 38)}px` : '6px',
                transition: 'all 0.15s cubic-bezier(0.175, 0.885, 0.32, 1.275)'
              }}
              className={`w-3 rounded-full ${
                isPlaying && activeNoteIdx === idx 
                  ? 'bg-gold shadow-[0_0_10px_rgba(201,160,80,0.5)]' 
                  : 'bg-zinc-800'
              }`}
            />
          ))}
        </div>

        {/* Dual adjustments slider (tempo & Volume) */}
        <div className="grid grid-cols-2 gap-4">
          <div>
            <div className="flex items-center justify-between text-[10px] font-mono tracking-wider text-warm-gray mb-1.5 uppercase">
              <span className="flex items-center gap-1">
                {volume === 0 ? <VolumeX className="w-3 h-3 text-gold" /> : <Volume2 className="w-3 h-3 text-gold" />}
                Awaaz (Loudness)
              </span>
              <span>{Math.round(volume * 100)}%</span>
            </div>
            <input
              id="slider-volume"
              type="range"
              min="0"
              max="0.8"
              step="0.1"
              value={volume}
              onChange={(e) => setVolume(parseFloat(e.target.value))}
              className="w-full accent-gold h-1 bg-zinc-800 rounded-lg cursor-pointer"
            />
          </div>
          <div>
            <div className="flex items-center justify-between text-[10px] font-mono tracking-wider text-warm-gray mb-1.5 uppercase">
              <span>Gana ki Speed</span>
              <span>{tempo}x</span>
            </div>
            <input
              id="slider-tempo"
              type="range"
              min="0.5"
              max="1.75"
              step="0.25"
              value={tempo}
              onChange={(e) => setTempo(parseFloat(e.target.value))}
              className="w-full accent-gold h-1 bg-zinc-800 rounded-lg cursor-pointer"
            />
          </div>
        </div>
      </div>
    </div>
  );
}
