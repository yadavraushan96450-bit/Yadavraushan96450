import React, { useState } from 'react';
import { Heart, Sparkles, BookOpen, Scroll, Orbit, Clipboard, Check, Loader2, AlertCircle } from 'lucide-react';

interface AiLoveLabProps {
  partnerName: string;
  anniversaryDate: string;
}

export default function AiLoveLab({ partnerName, anniversaryDate }: AiLoveLabProps) {
  const [activeTab, setActiveTab] = useState<'poem' | 'letter' | 'celestial'>('poem');
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);
  const [result, setResult] = useState<string>('');
  const [isFallback, setIsFallback] = useState(false);

  // States for Poem Composer
  const [poemTone, setPoemTone] = useState('nostalgic-deep');
  const [poemQuirks, setPoemQuirks] = useState('');

  // States for Letter scroll
  const [relationshipLength, setRelationshipLength] = useState('timeless eternity');
  const [favMemory, setFavMemory] = useState('');
  const [letterVibe, setLetterVibe] = useState('melodious-soft');

  // States for Celestial Astro alignment
  const [signA, setSignA] = useState('Aries');
  const [signB, setSignB] = useState('Leo');
  const [hobbiesA, setHobbiesA] = useState('stargazing & reading');
  const [hobbiesB, setHobbiesB] = useState('baking & drawing cozy things');

  const copyToClipboard = () => {
    if (!result) return;
    navigator.clipboard.writeText(result);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handlePoemSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setResult('');
    try {
      const response = await fetch('/api/generate/poem', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          partnerName: partnerName || 'Dearest',
          tone: poemTone,
          quirks: poemQuirks || 'bright happy eyes',
          anniversaryDate: anniversaryDate || 'our special year'
        })
      });
      const data = await response.json();
      setResult(data.text);
      setIsFallback(!!data.isFallback);
    } catch (err) {
      console.error(err);
      setResult("Celestial server nodes timing out... but here is a short sweet thought: I love you more than all the stars in the night canopy above.");
      setIsFallback(true);
    } finally {
      setLoading(false);
    }
  };

  const handleLetterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setResult('');
    try {
      const response = await fetch('/api/generate/letter', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          partnerName: partnerName || 'Love',
          senderName: 'Your Partner',
          favoriteMemory: favMemory || 'drinking warm cocoa together',
          relationshipLength,
          toneStyle: letterVibe
        })
      });
      const data = await response.json();
      setResult(data.text);
      setIsFallback(!!data.isFallback);
    } catch (err) {
      console.error(err);
      setResult("An unexpected cloud blocks the parchment delivery... but know that my heart is holding you close.");
      setIsFallback(true);
    } finally {
      setLoading(false);
    }
  };

  const handleAstroSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setResult('');
    try {
      const response = await fetch('/api/generate/alignment', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          signA,
          signB,
          activitiesA: hobbiesA,
          activitiesB: hobbiesB
        })
      });
      const data = await response.json();
      setResult(data.text);
      setIsFallback(!!data.isFallback);
    } catch (err) {
      console.error(err);
      setResult("A magnetic solar storm has obscured the charts... nonetheless, our souls resonate on a flawless cosmic scale.");
      setIsFallback(true);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div id="ai-love-lab-card" className="bg-dark-card backdrop-blur-md rounded-3xl border border-white/5 shadow-2xl p-6 md:p-8 max-w-2xl w-full mx-auto relative overflow-hidden">
      
      {/* Decorative starry background */}
      <div className="absolute top-0 right-0 w-32 h-32 bg-gold/5 rounded-full blur-[40px] pointer-events-none" />

      {/* Title */}
      <div className="flex items-center gap-3 mb-6">
        <div className="p-2.5 bg-gold/10 border border-gold/20 text-gold rounded-2xl">
          <Sparkles className="w-5 h-5 text-gold animate-pulse" id="love-lab-sparkle" />
        </div>
        <div>
          <h3 className="font-serif font-medium text-lg text-warm-white">Gemini Love Laboratory 🧪</h3>
          <p className="text-xs text-warm-gray">Gemini AI se pyari poemein, letters aur zodiac compatibility nikalo</p>
        </div>
      </div>

      {/* Tabs */}
      <div className="grid grid-cols-3 gap-2 border-b border-white/5 pb-4 mb-6">
        <button
          id="btn-tab-poem"
          onClick={() => { setActiveTab('poem'); setResult(''); }}
          className={`py-2 px-3 text-[10px] font-mono tracking-widest rounded-xl flex items-center justify-center gap-1.5 transition-all uppercase cursor-pointer ${
            activeTab === 'poem'
              ? 'bg-gold text-dark-bg font-bold shadow-md'
              : 'bg-zinc-950/40 hover:bg-white/5 text-warm-gray border border-white/5'
          }`}
        >
          <BookOpen className="w-3.5 h-3.5" />
          Pyaari Poem
        </button>
        <button
          id="btn-tab-letter"
          onClick={() => { setActiveTab('letter'); setResult(''); }}
          className={`py-2 px-3 text-[10px] font-mono tracking-widest rounded-xl flex items-center justify-center gap-1.5 transition-all uppercase cursor-pointer ${
            activeTab === 'letter'
              ? 'bg-gold text-dark-bg font-bold shadow-md'
              : 'bg-zinc-950/40 hover:bg-white/5 text-warm-gray border border-white/5'
          }`}
        >
          <Scroll className="w-3.5 h-3.5" />
          Pyaara Khat
        </button>
        <button
          id="btn-tab-celestial"
          onClick={() => { setActiveTab('celestial'); setResult(''); }}
          className={`py-2 px-3 text-[10px] font-mono tracking-widest rounded-xl flex items-center justify-center gap-1.5 transition-all uppercase cursor-pointer ${
            activeTab === 'celestial'
              ? 'bg-gold text-dark-bg font-bold shadow-md'
              : 'bg-zinc-950/40 hover:bg-white/5 text-warm-gray border border-white/5'
          }`}
        >
          <Orbit className="w-3.5 h-3.5" />
          Sitaron Ka Milan
        </button>
      </div>

      {/* Inputs Form */}
      <div className="space-y-4 mb-6">
        {activeTab === 'poem' && (
          <form onSubmit={handlePoemSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="text-[10px] uppercase font-mono font-bold tracking-widest text-warm-gray block mb-1.5">Poem Ka Tone Style</label>
                <select
                  id="select-tone"
                  value={poemTone}
                  onChange={(e) => setPoemTone(e.target.value)}
                  className="w-full text-xs p-3 rounded-lg border border-white/5 bg-zinc-950 text-warm-white focus:border-gold outline-none"
                >
                  <option value="nostalgic-deep">Yaadon Se Bhara aur Deep</option>
                  <option value="warm-cutesy">Sweet, Playful aur Dreamy</option>
                  <option value="regal-shakespearean">Shakespearean Vintage Sonnet Style</option>
                  <option value="modern-glowing">Ekdum Naya, Modern Emotion</option>
                </select>
              </div>
              <div>
                <label className="text-[10px] uppercase font-mono font-bold tracking-widest text-warm-gray block mb-1.5">Priya ki pyaari baatein ya quirks likhein</label>
                <input
                  id="input-quirks"
                  type="text"
                  placeholder="jaise: uski pyari dimpled hansi, har waqt baal twirl karna"
                  value={poemQuirks}
                  onChange={(e) => setPoemQuirks(e.target.value)}
                  className="w-full text-xs p-3 rounded-lg border border-white/5 bg-zinc-950 text-warm-white focus:border-gold outline-none"
                />
              </div>
            </div>
            <button
              id="generate-poem-btn"
              type="submit"
              disabled={loading}
              className="w-full py-3 bg-gold text-dark-bg font-bold rounded-xl text-[11px] tracking-widest uppercase flex items-center justify-center gap-2 hover:bg-gold/90 transition-all disabled:opacity-60 disabled:pointer-events-none cursor-pointer"
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin text-dark-bg" />
                  Gemini se pyari poetry likhwa rahe hain...
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4 text-dark-bg" />
                  Gemini Se Pyari Poem Likhao
                </>
              )}
            </button>
          </form>
        )}

        {activeTab === 'letter' && (
          <form onSubmit={handleLetterSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="text-[10px] uppercase font-mono font-bold tracking-widest text-warm-gray block mb-1.5">Sath ka samay / Kitne saal hue</label>
                <input
                  id="input-length"
                  type="text"
                  placeholder="jaise: 2 saal sath mein, ya 11 mahine ki dher saari khushiyan"
                  value={relationshipLength}
                  onChange={(e) => setRelationshipLength(e.target.value)}
                  className="w-full text-xs p-3 rounded-lg border border-white/5 bg-zinc-950 text-warm-white focus:border-gold outline-none"
                />
              </div>
              <div>
                <label className="text-[10px] uppercase font-mono font-bold tracking-widest text-warm-gray block mb-1.5">Khat (Letter) Ka Mood</label>
                <select
                  id="select-vibe"
                  value={letterVibe}
                  onChange={(e) => setLetterVibe(e.target.value)}
                  className="w-full text-xs p-3 rounded-lg border border-white/5 bg-zinc-950 text-warm-white focus:border-gold outline-none"
                >
                  <option value="melodious-soft">Pyara, Timeless aur Soft Theme</option>
                  <option value="ancient-museum-scroll">Sunehra Purana Vintage Khat</option>
                  <option value="futuristic-cyberstar">Immersive Cosmic / Star-crossed Lover</option>
                </select>
              </div>
            </div>
            <div>
              <label className="text-[10px] uppercase font-mono font-bold tracking-widest text-warm-gray block mb-1.5">Hamari Koi Pyaari Yaad Jo Khat Mein Shamil Karni Ho</label>
              <textarea
                id="area-memory"
                rows={2}
                placeholder="jaise: sath mein maggie khana ya baarish mein dher sari baatein karna"
                value={favMemory}
                onChange={(e) => setFavMemory(e.target.value)}
                className="w-full text-xs p-3 rounded-lg border border-white/5 bg-zinc-950 text-warm-white focus:border-gold outline-none resize-none"
              />
            </div>
            <button
              id="generate-letter-btn"
              type="submit"
              disabled={loading}
              className="w-full py-3 bg-gold text-dark-bg font-bold rounded-xl text-[11px] tracking-widest uppercase flex items-center justify-center gap-2 hover:bg-gold/90 transition-all disabled:opacity-60 disabled:pointer-events-none cursor-pointer"
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin text-dark-bg" />
                  Yaadon ko khat par sunehre aksharo mein likh rahe hain...
                </>
              ) : (
                <>
                  <Scroll className="w-4 h-4 text-dark-bg" />
                  Gemini Se Pyaara Letter Likhao
                </>
              )}
            </button>
          </form>
        )}

        {activeTab === 'celestial' && (
          <form onSubmit={handleAstroSubmit} className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-[10px] uppercase font-mono font-bold tracking-widest text-warm-gray block mb-1.5">Aapki Rashi (Zodiac)</label>
                <select
                  id="select-astro-a"
                  value={signA}
                  onChange={(e) => setSignA(e.target.value)}
                  className="w-full text-xs p-3 rounded-lg border border-white/5 bg-zinc-950 text-warm-white focus:border-gold outline-none"
                >
                  {['Aries', 'Taurus', 'Gemini', 'Cancer', 'Leo', 'Virgo', 'Libra', 'Scorpio', 'Sagittarius', 'Capricorn', 'Aquarius', 'Pisces'].map(x => (
                    <option key={x} value={x}>{x}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="text-[10px] uppercase font-mono font-bold tracking-widest text-warm-gray block mb-1.5">Uski Rashi (Partner Zodiac)</label>
                <select
                  id="select-astro-b"
                  value={signB}
                  onChange={(e) => setSignB(e.target.value)}
                  className="w-full text-xs p-3 rounded-lg border border-white/5 bg-zinc-950 text-warm-white focus:border-gold outline-none"
                >
                  {['Aries', 'Taurus', 'Gemini', 'Cancer', 'Leo', 'Virgo', 'Libra', 'Scorpio', 'Sagittarius', 'Capricorn', 'Aquarius', 'Pisces'].map(x => (
                    <option key={x} value={x}>{x}</option>
                  ))}
                </select>
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="text-[10px] uppercase font-mono font-bold tracking-widest text-warm-gray block mb-1.5">Aapko Sabse Zyada Kya Pasand Hai</label>
                <input
                  id="astro-hobbies-a"
                  type="text"
                  value={hobbiesA}
                  onChange={(e) => setHobbiesA(e.target.value)}
                  className="w-full text-xs p-3 rounded-lg border border-white/5 bg-zinc-950 text-warm-white focus:border-gold outline-none"
                />
              </div>
              <div>
                <label className="text-[10px] uppercase font-mono font-bold tracking-widest text-warm-gray block mb-1.5">Use Sabse Zyada Kya Pasand Hai</label>
                <input
                  id="astro-hobbies-b"
                  type="text"
                  value={hobbiesB}
                  onChange={(e) => setHobbiesB(e.target.value)}
                  className="w-full text-xs p-3 rounded-lg border border-white/5 bg-zinc-950 text-warm-white focus:border-gold outline-none"
                />
              </div>
            </div>
            <button
              id="generate-astro-btn"
              type="submit"
              disabled={loading}
              className="w-full py-3 bg-gold text-dark-bg font-bold rounded-xl text-[11px] tracking-widest uppercase flex items-center justify-center gap-2 hover:bg-gold/90 transition-all disabled:opacity-60 disabled:pointer-events-none cursor-pointer"
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin text-dark-bg" />
                  Gemini can check stars alignment compatibility...
                </>
              ) : (
                <>
                  <Orbit className="w-4 h-4 text-dark-bg animate-spin-slow" />
                  Sitaron Ka Milan Compatibility Match Karo
                </>
              )}
            </button>
          </form>
        )}
      </div>

      {/* Output Response Screen */}
      {result && (
        <div id="ai-love-lab-output" className="p-6 md:p-8 bg-zinc-950/60 border border-white/5 rounded-2xl relative animate-fade-in">
          
          <div className="absolute top-4 right-4 flex items-center gap-2">
            <button
              id="copy-to-clipboard-btn"
              onClick={copyToClipboard}
              className="p-2 rounded-lg bg-zinc-950 border border-white/10 hover:bg-white/5 text-gold hover:text-warm-white transition-all flex items-center gap-1 text-[11px] cursor-pointer"
              title="Copy to Clipboard"
            >
              {copied ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-500" />
                  <span>Copy Ho Gaya!</span>
                </>
              ) : (
                <>
                  <Clipboard className="w-3.5 h-3.5" />
                  <span>Copy Karo</span>
                </>
              )}
            </button>
          </div>

          <span className="text-[9px] font-mono font-bold tracking-widest text-[#c9a050] block mb-4 uppercase">
            Gemini Ka Jawab
          </span>

          {/* Render beautifully formatted romantic text */}
          <div className="font-serif text-sm md:text-base leading-relaxed text-[#f4efe8] whitespace-pre-wrap max-h-72 overflow-y-auto pr-2 custom-scrollbar italic font-light">
            {result}
          </div>

          {isFallback && (
            <div className="mt-4 p-3 bg-amber-500/10 border border-amber-500/20 text-[10px] text-amber-500 rounded-xl flex items-center gap-1.5 leading-relaxed">
              <AlertCircle className="w-3.5 h-3.5 shrink-0" />
              <span>Offline preview chal raha hai. Live live features chalane ke liye secrets tab mein GEMINI_API_KEY set karein!</span>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
