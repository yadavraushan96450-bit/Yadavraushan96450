import React, { useState } from 'react';
import { LoveMemory } from '../types';
import { Calendar, PlusCircle, Heart, FolderHeart, Image as ImageIcon } from 'lucide-react';

interface MemoryLaneProps {
  memories: LoveMemory[];
  onAddMemory?: (memory: Omit<LoveMemory, 'id'>) => void;
}

export default function MemoryLane({ memories, onAddMemory }: MemoryLaneProps) {
  const [filter, setFilter] = useState<string>('all');
  const [showAddForm, setShowAddForm] = useState(false);

  // Form states
  const [newTitle, setNewTitle] = useState('');
  const [newDate, setNewDate] = useState('');
  const [newText, setNewText] = useState('');
  const [newCategory, setNewCategory] = useState<LoveMemory['category']>('Sweet Moments');
  const [newPicsumSeed, setNewPicsumSeed] = useState('heart');

  const categories: Array<LoveMemory['category'] | 'all'> = [
    'all',
    'First Met',
    'Special Date',
    'Adventures',
    'Sweet Moments',
    'Milestone'
  ];

  const filteredMemories = filter === 'all'
    ? memories
    : memories.filter(m => m.category === filter);

  // Sorted by date closest to furthest, or standard chronological
  const sortedMemories = [...filteredMemories].sort((a, b) => 
    new Date(a.date).getTime() - new Date(b.date).getTime()
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim() || !newDate || !newText.trim()) return;

    if (onAddMemory) {
      onAddMemory({
        title: newTitle,
        date: newDate,
        text: newText,
        category: newCategory,
        imageUrl: `https://picsum.photos/seed/${newPicsumSeed || 'heart'}/600/400`
      });
    }

    // Reset Form
    setNewTitle('');
    setNewDate('');
    setNewText('');
    setNewCategory('Sweet Moments');
    setNewPicsumSeed('love');
    setShowAddForm(false);
  };

  return (
    <div id="memory-lane-timeline-deck" className="w-full max-w-2xl mx-auto space-y-8">
      
      {/* Category Filter Pills */}
      <div className="flex flex-wrap gap-2 justify-center py-2 border-b border-white/5">
        {categories.map((cat) => {
          let displayLabel: string = cat;
          if (cat === 'all') displayLabel = 'Saari Yaadein 📂';
          else if (cat === 'First Met') displayLabel = 'Pehli Mulaqat 💖';
          else if (cat === 'Special Date') displayLabel = 'Special Date 🌹';
          else if (cat === 'Adventures') displayLabel = 'Sath Me Safar ✈️';
          else if (cat === 'Sweet Moments') displayLabel = 'Cozy Lamhe ✨';
          else if (cat === 'Milestone') displayLabel = 'Zindagi Ke Milestones 👑';

          return (
            <button
              key={cat}
              id={`filter-cat-${cat.replace(/\s+/g, '-').toLowerCase()}`}
              onClick={() => setFilter(cat)}
              className={`px-3.5 py-1.5 rounded-full text-xs font-semibold font-sans transition-all hover:scale-105 active:scale-95 cursor-pointer uppercase tracking-wider text-[10px] ${
                filter === cat
                  ? 'bg-gold text-dark-bg shadow-sm font-bold'
                  : 'bg-zinc-950/40 hover:bg-white/5 text-warm-gray border border-white/5'
              }`}
            >
              {displayLabel}
            </button>
          );
        })}
      </div>

      {/* Adding a Quick Love Marker */}
      <div className="flex justify-center">
        <button
          id="toggle-add-memory-form"
          onClick={() => setShowAddForm(!showAddForm)}
          className="px-4 py-2 bg-gold hover:bg-gold/90 text-dark-bg text-xs font-bold rounded-full flex items-center gap-1.5 shadow-sm hover:scale-105 active:scale-95 transition-all cursor-pointer uppercase tracking-widest"
        >
          <PlusCircle className="w-4 h-4" />
          {showAddForm ? 'Nayi Yaad Shamil Karna Chhodein' : 'Apni KoyI Pyaari Yaad Likhein 📝'}
        </button>
      </div>

      {showAddForm && (
        <form
          onSubmit={handleSubmit}
          id="add-memory-form"
          className="bg-dark-card p-6 rounded-2xl border border-white/5 shadow-2xl space-y-4 max-w-md mx-auto animate-slide-up"
        >
          <h4 className="font-serif text-base font-semibold text-warm-white flex items-center gap-1.5 mb-1">
            <FolderHeart className="w-4 h-4 text-gold" />
            Hamari Ek Pyaari Yaad Likhein
          </h4>

          <div className="space-y-3">
            <div>
              <label className="text-[10px] uppercase tracking-widest font-mono font-bold text-warm-gray block mb-1">Yaad Ka Naam (Title)</label>
              <input
                id="mem-title-input"
                type="text"
                required
                placeholder="jaise: Jab hum pehli baar thand mein ghumne gaye the"
                value={newTitle}
                onChange={(e) => setNewTitle(e.target.value)}
                className="w-full text-xs p-3 rounded-lg border border-white/5 bg-zinc-950 text-warm-white focus:border-gold outline-none"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-[10px] uppercase tracking-widest font-mono font-bold text-warm-gray block mb-1">Yaad Ki Date</label>
                <input
                  id="mem-date-input"
                  type="date"
                  required
                  value={newDate}
                  onChange={(e) => setNewDate(e.target.value)}
                  className="w-full text-xs p-3 rounded-lg border border-white/5 bg-zinc-950 text-warm-white focus:border-gold outline-none"
                />
              </div>
              <div>
                <label className="text-[10px] uppercase tracking-widest font-mono font-bold text-warm-gray block mb-1">Yaad Ki Category</label>
                <select
                  id="mem-cat-select"
                  value={newCategory}
                  onChange={(e) => setNewCategory(e.target.value as LoveMemory['category'])}
                  className="w-full text-xs p-3 rounded-lg border border-white/5 bg-zinc-950 text-warm-white focus:border-gold outline-none"
                >
                  <option value="First Met">Pehli Mulaqat 💖</option>
                  <option value="Special Date">Special Date 🌹</option>
                  <option value="Adventures">Sath Me Safar ✈️</option>
                  <option value="Sweet Moments">Cozy Lamhe ✨</option>
                  <option value="Milestone">Zindagi Ke Milestones 👑</option>
                </select>
              </div>
            </div>

            <div>
              <label className="text-[10px] uppercase tracking-widest font-mono font-bold text-warm-gray block mb-1">Photo Ka Mood (Picsum Seed Keyword)</label>
              <input
                id="mem-seed-input"
                type="text"
                placeholder="jaise: blossom, rain, coffee, camp, beach"
                value={newPicsumSeed}
                onChange={(e) => setNewPicsumSeed(e.target.value)}
                className="w-full text-xs p-3 rounded-lg border border-white/5 bg-zinc-950 text-warm-white focus:border-gold outline-none"
              />
            </div>

            <div>
              <label className="text-[10px] uppercase tracking-widest font-mono font-bold text-warm-gray block mb-1">Kahani Ke Haseen Details</label>
              <textarea
                id="mem-text-input"
                rows={3}
                required
                placeholder="Hamare is sunehre lamhe ke baare mein dher saari baatein likhein..."
                value={newText}
                onChange={(e) => setNewText(e.target.value)}
                className="w-full text-xs p-3 rounded-lg border border-white/5 bg-zinc-950 text-warm-white focus:border-gold outline-none resize-none"
              />
            </div>
          </div>

          <button
            id="mem-submit-btn"
            type="submit"
            className="w-full py-2.5 bg-gold text-dark-bg rounded-lg text-xs font-bold hover:bg-gold/90 transition-colors cursor-pointer uppercase tracking-widest"
          >
            Sunehri Timeline Mein Save Karein 💖
          </button>
        </form>
      )}

      {/* Vertical Timeline Tree Layout */}
      {sortedMemories.length === 0 ? (
        <div className="bg-dark-card p-8 rounded-2xl text-center text-xs text-warm-gray border border-white/5 border-dashed">
          Is category mein abhi koi yaad nahi mili. Kuch naya likhein ya fir 'Saari Yaadein' dekhne ke liye click karein!
        </div>
      ) : (
        <div id="vertical-timeline-tree" className="relative border-l-2 border-white/5 pl-6 md:pl-8 ml-3 space-y-12">
          {sortedMemories.map((mem, idx) => {
            let cardCat = mem.category as string;
            if (cardCat === 'First Met') cardCat = 'Pehli Mulaqat 💖';
            else if (cardCat === 'Special Date') cardCat = 'Special Date 🌹';
            else if (cardCat === 'Adventures') cardCat = 'Sath Me Safar ✈️';
            else if (cardCat === 'Sweet Moments') cardCat = 'Cozy Lamhe ✨';
            else if (cardCat === 'Milestone') cardCat = 'Zindagi Ke Milestones 👑';

            return (
              <div
                key={mem.id || idx}
                id={`timeline-card-${mem.id || idx}`}
                className="relative group transition-all"
              >
                {/* Timeline dot */}
                <div className="absolute -left-[35px] md:-left-[43px] top-1.5 w-6 h-6 bg-gold rounded-full border-4 border-dark-bg flex items-center justify-center text-dark-bg scale-110 shadow-md">
                  <Heart className="w-2.5 h-2.5 fill-dark-bg text-dark-bg" />
                </div>

                {/* Memory Card */}
                <div className="bg-dark-card text-warm-white border border-white/5 rounded-2xl overflow-hidden shadow-2xl group-hover:shadow-3xl transition-transform duration-300 md:group-hover:scale-[1.01] flex flex-col md:flex-row">
                  {/* Photo space */}
                  <div className="relative md:w-2/5 shrink-0 h-48 md:h-auto overflow-hidden bg-[#1e1717]">
                    <img
                      src={mem.imageUrl}
                      alt={mem.title}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    <span className="absolute top-3 left-3 px-2.5 py-1 text-[9px] font-bold font-mono tracking-widest uppercase bg-[#0d0a0adf]/90 backdrop-blur-md text-gold rounded border border-gold/20">
                      {cardCat}
                    </span>
                  </div>

                  {/* Content space */}
                  <div className="p-6 flex-1 flex flex-col justify-between">
                    <div>
                      <div className="flex items-center gap-1.5 text-gold font-mono text-xs font-bold mb-2 uppercase tracking-wider">
                        <Calendar className="w-3.5 h-3.5" />
                        <span>{new Date(mem.date).toLocaleDateString('en-IN', { year: 'numeric', month: 'long', day: 'numeric' })}</span>
                      </div>

                      <h4 className="font-serif font-semibold text-lg text-warm-white mb-2 group-hover:text-gold transition-colors">
                        {mem.title}
                      </h4>

                      <p className="text-warm-gray text-xs md:text-sm leading-relaxed mb-4 whitespace-pre-wrap font-light">
                        {mem.text}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
