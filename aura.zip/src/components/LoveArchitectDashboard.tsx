import React, { useState } from 'react';
import { SurpriseSettings, QuizQuestion, ThemePalette } from '../types';
import { Settings, Save, Sparkles, Heart, Trash2, Code, Plus, HelpCircle, Check } from 'lucide-react';

interface LoveArchitectDashboardProps {
  settings: SurpriseSettings;
  onUpdateSettings: (settings: SurpriseSettings) => void;
  onFactoryReset: () => void;
}

export default function LoveArchitectDashboard({ settings, onUpdateSettings, onFactoryReset }: LoveArchitectDashboardProps) {
  const [activeSubTab, setActiveSubTab] = useState<'basic' | 'quiz' | 'wishes'>('basic');
  const [showConfig, setShowConfig] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);

  // Copy states
  const [copyCodeMode, setCopyCodeMode] = useState(false);

  const handleBasicChange = (field: keyof SurpriseSettings, value: any) => {
    onUpdateSettings({
      ...settings,
      [field]: value
    });
  };

  // Theme presets helper
  const PALETTES: Record<ThemePalette, { name: string; class: string }> = {
    'rose-romance': { name: 'Blushing Rose & Slate (Default Classic)', class: 'bg-rose-500' },
    'celestial-indigo': { name: 'Celestial Star Indigo (Midnight Vibe)', class: 'bg-indigo-650' },
    'emerald-serenade': { name: 'Emerald Forest Serenade (Warm Cozy)', class: 'bg-emerald-650' },
    'vintage-parchment': { name: 'Vintage Museum Parchment', class: 'bg-amber-600' }
  };

  // State addition for New Quiz custom questions
  const [newQText, setNewQText] = useState('');
  const [newQOpts, setNewQOpts] = useState<string[]>(['', '', '']);
  const [newQCorrectIdx, setNewQCorrectIdx] = useState(0);
  const [newQCorrectMsg, setNewQCorrectMsg] = useState('Spot on! ❤️');
  const [newQWrongMsg, setNewQWrongMsg] = useState('Almost! I love you anyway.');

  const handleAddQuestion = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newQText.trim() || newQOpts.some(o => !o.trim())) return;

    const newQuestion: QuizQuestion = {
      id: `q-${Date.now()}`,
      question: newQText,
      options: newQOpts.filter(o => o.trim() !== ''),
      correctAnswerIndex: newQCorrectIdx,
      messageIfCorrect: newQCorrectMsg,
      messageIfWrong: newQWrongMsg
    };

    onUpdateSettings({
      ...settings,
      quizQuestions: [...settings.quizQuestions, newQuestion]
    });

    // Reset fields
    setNewQText('');
    setNewQOpts(['', '', '']);
    setNewQCorrectIdx(0);
  };

  const handleDeleteQuestion = (id: string) => {
    onUpdateSettings({
      ...settings,
      quizQuestions: settings.quizQuestions.filter(q => q.id !== id)
    });
  };

  const handleSaveNotification = () => {
    setSaveSuccess(true);
    setTimeout(() => setSaveSuccess(false), 2000);
  };

  return (
    <div id="love-architect-main-card" className="w-full max-w-4xl mx-auto bg-dark-card text-warm-white rounded-3xl p-6 md:p-8 border border-white/5 shadow-2xl relative overflow-hidden">
      
      {/* Visual background elements */}
      <div className="absolute top-0 left-0 w-32 h-32 bg-gold/5 rounded-full blur-[40px] pointer-events-none" />

      {/* Controller header */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between pb-6 border-b border-white/5 gap-4 mb-6">
        <div>
          <span className="text-[10px] uppercase tracking-wider font-bold text-gold font-mono flex items-center gap-1.5 mb-1.5">
            <Sparkles className="w-3.5 h-3.5 animate-pulse text-gold" />
            Live App Modifier (No-Code Customizer Mode) 🛠️
          </span>
          <h2 className="font-serif font-semibold text-2xl text-warm-white">The Love Architect</h2>
          <p className="text-xs text-warm-gray">Apni Priya ka naam, Birthdate, Quiz sawal, aur beautiful themes badlein. Real-time mein update hoga!</p>
        </div>

        <button
          id="toggle-architect-view"
          onClick={() => setShowConfig(!showConfig)}
          className={`py-2 px-5 rounded-xl font-bold text-xs transition-all uppercase tracking-wider flex items-center gap-1.5 hover:scale-105 active:scale-95 cursor-pointer ${
            showConfig ? 'bg-gold text-dark-bg shadow-lg' : 'bg-zinc-950 border border-white/10 text-gold hover:bg-white/5'
          }`}
        >
          <Settings className="w-3.5 h-3.5" />
          {showConfig ? "Settings Chhupao" : "Settings Panel Kholo"}
        </button>
      </div>

      {showConfig ? (
        <div id="architect-board-content" className="space-y-6">
          {/* Sub Menu tabs */}
          <div className="flex gap-2 border-b border-white/5 pb-3">
            {['basic', 'quiz', 'wishes'].map((tab) => (
              <button
                key={tab}
                id={`subtab-${tab}`}
                onClick={() => setActiveSubTab(tab as any)}
                className={`px-4 py-1.5 text-[10px] rounded-lg transition-all font-mono tracking-wider uppercase cursor-pointer ${
                  activeSubTab === tab 
                    ? 'bg-zinc-950 text-gold border border-gold/20' 
                    : 'text-warm-gray hover:text-warm-white'
                }`}
              >
                {tab === 'basic' ? 'Basic Info & Theme' : tab === 'quiz' ? 'Surprise Quiz Settings' : 'Note Jar & Wishing Stars'}
              </button>
            ))}
          </div>

          {activeSubTab === 'basic' && (
            <div id="subtab-basic-form" className="grid grid-cols-1 md:grid-cols-2 gap-6 animate-fade-in">
              <div className="space-y-4">
                <h3 className="text-xs font-bold uppercase tracking-widest text-[#c9a050] font-sans flex items-center gap-1.5">
                  <Heart className="w-4 h-4 text-gold fill-gold" />
                  Mukhya Settings
                </h3>

                <div>
                  <label className="text-[10px] font-mono font-bold uppercase tracking-widest text-warm-gray block mb-1">Priya Ka Pyaara Naam (Partner Name)</label>
                  <input
                    id="input-arch-partner"
                    type="text"
                    value={settings.partnerName}
                    onChange={(e) => handleBasicChange('partnerName', e.target.value)}
                    className="w-full text-xs p-3 rounded-lg border border-white/5 bg-zinc-950 text-warm-white focus:border-gold outline-none"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-[10px] font-mono font-bold uppercase tracking-widest text-warm-gray block mb-1">Uski Birthdate</label>
                    <input
                      id="input-arch-birth"
                      type="date"
                      value={settings.birthdate}
                      onChange={(e) => handleBasicChange('birthdate', e.target.value)}
                      className="w-full text-xs p-3 rounded-lg border border-white/5 bg-zinc-950 text-warm-white outline-none focus:border-gold"
                    />
                  </div>
                  <div>
                    <label className="text-[10px] font-mono font-bold uppercase tracking-widest text-warm-gray block mb-1">Sath Aane Ki Date (Anniversary)</label>
                    <input
                      id="input-arch-anniv"
                      type="date"
                      value={settings.anniversaryDate}
                      onChange={(e) => handleBasicChange('anniversaryDate', e.target.value)}
                      className="w-full text-xs p-3 rounded-lg border border-white/5 bg-zinc-950 text-warm-white outline-none focus:border-gold"
                    />
                  </div>
                </div>

                <div>
                  <label className="text-[10px] font-mono font-bold uppercase tracking-widest text-warm-gray block mb-1">Surprise Website Ki Heading (Title)</label>
                  <input
                    id="input-arch-title"
                    type="text"
                    value={settings.customTitle}
                    onChange={(e) => handleBasicChange('customTitle', e.target.value)}
                    className="w-full text-xs p-3 rounded-lg border border-white/5 bg-zinc-950 text-warm-white focus:border-gold outline-none"
                  />
                </div>
              </div>

              <div className="space-y-4">
                <h3 className="text-xs font-bold uppercase tracking-widest text-[#c9a050] font-sans">Sundar Themes</h3>
                
                <div>
                  <label className="text-[10px] font-mono font-bold uppercase tracking-widest text-warm-gray block mb-2">Website Ka Background Color Set</label>
                  <div className="grid grid-cols-1 gap-2">
                    {(Object.keys(PALETTES) as Array<ThemePalette>).map((k) => (
                      <button
                        key={k}
                        id={`palette-btn-${k}`}
                        onClick={() => handleBasicChange('palette', k)}
                        className={`flex items-center justify-between p-3 rounded-xl border transition-all text-left text-xs cursor-pointer ${
                          settings.palette === k
                            ? 'border-gold bg-zinc-950'
                            : 'border-white/5 bg-zinc-950/40 opacity-70 hover:opacity-100'
                        }`}
                      >
                        <span className="font-semibold text-warm-white">{PALETTES[k].name}</span>
                        <div className={`w-3.5 h-3.5 rounded-full ${PALETTES[k].class}`} />
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="text-[10px] font-mono font-bold uppercase tracking-widest text-warm-gray block mb-1">Surprise Lockscreen Ka Passcode</label>
                  <input
                    id="input-arch-key"
                    type="text"
                    value={settings.secretPasscode}
                    placeholder="e.g. 143"
                    onChange={(e) => handleBasicChange('secretPasscode', e.target.value)}
                    className="w-full text-xs p-3 rounded-lg border border-white/5 bg-zinc-950 text-warm-white focus:border-gold outline-none"
                  />
                  <p className="text-[10px] text-warm-gray mt-1 font-sans">Jab tak ye passcode nahi daalenge, birthday app surprise lock rahega!</p>
                </div>
              </div>
            </div>
          )}

          {activeSubTab === 'quiz' && (
            <div id="subtab-quiz-form" className="space-y-4 animate-fade-in">
              <h3 className="text-[11px] font-mono font-bold uppercase tracking-widest text-warm-gray font-sans">Quiz Ke Sawal Answer Settings ({settings.quizQuestions.length})</h3>

              {/* Quick Table representation of current questions */}
              <div className="space-y-2 max-h-40 overflow-y-auto pr-2">
                {settings.quizQuestions.map((q, qidx) => (
                  <div key={q.id} className="flex items-center justify-between p-3 rounded-xl bg-zinc-950 text-xs border border-white/5">
                    <div className="text-warm-white">
                      <strong className="text-gold font-mono mr-1">Sawal {qidx + 1}: </strong>
                      <span className="italic font-light">"{q.question}"</span>
                    </div>
                    <button
                      id={`delete-question-${q.id}`}
                      onClick={() => { handleDeleteQuestion(q.id); handleSaveNotification(); }}
                      className="p-1.5 bg-rose-950/40 text-rose-400 hover:bg-rose-900/40 rounded-lg transition-colors cursor-pointer"
                      title="Sawal Hatao"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>

              {/* Form to insert quick trivia questions */}
              <form onSubmit={handleAddQuestion} className="bg-zinc-950/60 p-4 border border-white/5 rounded-2xl space-y-3">
                <h4 className="text-xs font-bold text-gold flex items-center gap-1">
                  <Plus className="w-4 h-4 text-gold" />
                  Naya Custom Sawal Shamil Karein
                </h4>

                <div>
                  <label className="text-[10px] font-mono font-bold uppercase tracking-widest text-warm-gray block mb-1">Sawal Ka Text</label>
                  <input
                    id="new-question-text"
                    type="text"
                    required
                    placeholder="jaise: Hum pehli baar kahan ghumne gaye the?"
                    value={newQText}
                    onChange={(e) => setNewQText(e.target.value)}
                    className="w-full text-xs p-2.5 rounded-lg border border-white/5 bg-zinc-900 text-warm-white outline-none focus:border-gold"
                  />
                </div>

                <div className="grid grid-cols-3 gap-2">
                  {newQOpts.map((opt, oidx) => (
                    <div key={oidx}>
                      <label className="text-[10px] font-mono font-bold uppercase tracking-widest text-warm-gray block mb-1">Option {oidx + 1}</label>
                      <input
                        id={`new-opt-input-${oidx}`}
                        required
                        type="text"
                        placeholder={`Option ${oidx + 1}`}
                        value={opt}
                        onChange={(e) => {
                          const updated = [...newQOpts];
                          updated[oidx] = e.target.value;
                          setNewQOpts(updated);
                        }}
                        className="w-full text-xs p-2.5 rounded-lg border border-white/5 bg-zinc-900 text-warm-white outline-none focus:border-gold"
                      />
                    </div>
                  ))}
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-[10px] font-mono font-bold uppercase tracking-widest text-warm-gray block mb-1">Sahi Option Konsa Hai (0 to 2)</label>
                    <select
                      id="new-correct-idx"
                      value={newQCorrectIdx}
                      onChange={(e) => setNewQCorrectIdx(parseInt(e.target.value))}
                      className="w-full text-xs p-2.5 rounded-lg border border-white/5 bg-zinc-900 text-warm-white outline-none focus:border-gold"
                    >
                      <option value="0">Option 1</option>
                      <option value="1">Option 2</option>
                      <option value="2">Option 3</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-[10px] font-mono font-bold uppercase tracking-widest text-warm-gray block mb-1">Sahi Jawab Ka Dialogue (Feedback message)</label>
                    <input
                      id="new-correct-msg"
                      type="text"
                      value={newQCorrectMsg}
                      onChange={(e) => setNewQCorrectMsg(e.target.value)}
                      className="w-full text-xs p-2.5 rounded-lg border border-white/5 bg-zinc-900 text-warm-white outline-none focus:border-gold"
                    />
                  </div>
                </div>

                <button
                  id="add-question-btn"
                  type="submit"
                  className="py-2 px-4 bg-gold text-dark-bg text-[10px] font-bold uppercase tracking-widest rounded-lg hover:bg-gold/90 transition-colors cursor-pointer"
                >
                  Sawal Add Karo
                </button>
              </form>
            </div>
          )}

          {activeSubTab === 'wishes' && (
            <div id="subtab-wishes-form" className="grid grid-cols-1 md:grid-cols-2 gap-6 animate-fade-in">
              <div className="space-y-4">
                <h3 className="text-xs font-bold uppercase tracking-widest text-warm-gray font-sans">Aasmaani Taare aur Wish Lanterns (Maksimum 5)</h3>
                
                {settings.starWishes.map((w, index) => (
                  <div key={index} className="space-y-1">
                    <label className="text-[10px] font-mono font-bold uppercase tracking-widest text-zinc-500 block">Wish Taara #{index + 1}</label>
                    <input
                      id={`star-wish-input-${index}`}
                      type="text"
                      value={w}
                      onChange={(e) => {
                        const updated = [...settings.starWishes];
                        updated[index] = e.target.value;
                        handleBasicChange('starWishes', updated);
                      }}
                      className="w-full text-xs p-3 rounded-lg border border-white/5 bg-zinc-950 text-warm-white outline-none focus:border-gold"
                    />
                  </div>
                ))}
              </div>

              <div className="space-y-4">
                <h3 className="text-xs font-bold uppercase tracking-widest text-warm-gray font-sans">Dil Ki Baatein Confession Notes (Maksimum 6)</h3>

                <div className="space-y-3 max-h-72 overflow-y-auto pr-2">
                  {settings.jarNotes.map((n, index) => (
                    <div key={index} className="space-y-1">
                      <label className="text-[10px] font-mono font-bold uppercase tracking-widest text-zinc-500 block">Confession Note #{index + 1}</label>
                      <input
                        id={`jar-note-input-${index}`}
                        type="text"
                        value={n}
                        onChange={(e) => {
                          const updated = [...settings.jarNotes];
                          updated[index] = e.target.value;
                          handleBasicChange('jarNotes', updated);
                        }}
                        className="w-full text-xs p-3 bg-zinc-950 border border-white/5 text-warm-white rounded-lg outline-none focus:border-gold"
                      />
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          <div className="flex flex-wrap items-center justify-between border-t border-white/5 pt-6 gap-4">
            <div className="flex gap-2">
              <button
                id="save-surprises-btn"
                onClick={handleSaveNotification}
                className="py-2.5 px-6 bg-gold text-dark-bg text-xs font-bold uppercase tracking-widest rounded-xl flex items-center gap-1.5 hover:bg-gold/90 active:scale-95 transition-all cursor-pointer shadow-md"
              >
                <Save className="w-4 h-4 text-dark-bg" />
                {saveSuccess ? "Sab Kuch Save Ho Gaya! ❤️" : "Sabhi Changes Save Karein"}
              </button>

              <button
                id="factory-reset-btn"
                onClick={() => { onFactoryReset(); handleSaveNotification(); }}
                className="py-2.5 px-4 bg-zinc-950 border border-white/10 hover:bg-white/5 text-rose-400 font-bold uppercase tracking-widest text-xs rounded-xl transition-all cursor-pointer"
                title="Reset back to sweet Emma defaults"
              >
                Puraani Defaults Reset Karo
              </button>
            </div>

            <button
              id="toggle-export-json"
              onClick={() => setCopyCodeMode(!copyCodeMode)}
              className="py-2 px-3 bg-zinc-950 hover:bg-white/5 border border-white/10 text-gold text-[10px] uppercase font-mono tracking-widest rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <Code className="w-3.5 h-3.5 text-gold" />
              {copyCodeMode ? "Code Chhupao" : "Apna Custom Backup Code Export Karo"}
            </button>
          </div>

          {copyCodeMode && (
            <div id="exported-preset-json" className="bg-zinc-950 p-4 border border-white/5 rounded-2xl animate-fade-in relative">
              <span className="text-[9px] font-mono font-bold text-gold block mb-2 uppercase">Custom Export Code</span>
              <p className="text-[10px] text-warm-gray mb-2 leading-relaxed">Aap is JSON config code ko kahin bhi copy karke backup rakh sakte hain!</p>
              <pre className="text-[10px] text-gold font-mono overflow-x-auto max-h-40 bg-zinc-900 w-full p-2.5 rounded-lg border border-white/5 whitespace-pre-wrap">
                {JSON.stringify(settings, null, 2)}
              </pre>
            </div>
          )}
        </div>
      ) : (
        <div id="architect-minimized-hint" className="text-center py-2 flex items-center justify-center gap-2 text-warm-gray text-xs">
          <span>Settings panel closed hai. Isey khol kar sabhi text, sawal aur designs badlein!</span>
        </div>
      )}
    </div>
  );
}
