/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface LoveMemory {
  id: string;
  date: string;
  title: string;
  text: string;
  imageUrl: string;
  category: 'First Met' | 'Special Date' | 'Adventures' | 'Sweet Moments' | 'Milestone';
}

export interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctAnswerIndex: number;
  messageIfCorrect: string;
  messageIfWrong: string;
}

export interface WishingMessage {
  id: string;
  text: string;
  author: string;
}

export type ThemePalette = 'rose-romance' | 'celestial-indigo' | 'emerald-serenade' | 'vintage-parchment';

export interface SurpriseSettings {
  partnerName: string;
  anniversaryDate: string;
  birthdate: string;
  secretPasscode: string;
  customTitle: string;
  relationshipGoal: string;
  palette: ThemePalette;
  memories: LoveMemory[];
  quizQuestions: QuizQuestion[];
  starWishes: string[];
  jarNotes: string[];
}
