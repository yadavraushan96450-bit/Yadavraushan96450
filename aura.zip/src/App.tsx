/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { LoveMemory, QuizQuestion, SurpriseSettings, ThemePalette } from './types';
import AudioSynthesizer from './components/AudioSynthesizer';
import InteractiveQuiz from './components/InteractiveQuiz';
import StargazingCanvas from './components/StargazingCanvas';
import HeartWishJar from './components/HeartWishJar';
import AiLoveLab from './components/AiLoveLab';
import MemoryLane from './components/MemoryLane';
import LoveArchitectDashboard from './components/LoveArchitectDashboard';
import { Heart, Calendar, Lock, Unlock, Mail, Sparkles, Clock, Compass, BookOpen, Music, Settings, AlertCircle } from 'lucide-react';

const DEFAULT_SETTINGS: SurpriseSettings = {
  partnerName: 'Priya',
  anniversaryDate: '2024-11-20', // future/historical reference
  birthdate: '2026-06-03', // Exact date of today in metadata! Magical greeting.
  secretPasscode: '0603', // June 3rd
  customTitle: 'Uss ladki ke liye jo apni aankhon mein sitare lekar chalti hai 💖',
  relationshipGoal: 'Sath mein camera se stars capture karna aur hamesha ek hi blanket share karna.',
  palette: 'rose-romance',
  memories: [
    {
      id: 'm-1',
      date: '2024-11-20',
      title: 'Hamari Giri Hui Cinnamon Latte',
      text: 'Tum library mein rug corner se takra gayin aur apni garam latte seedhe mere draft sketchbook par gira di. Tum baar-baar sorry bol rahi thi, lekin tumhare laal aur masoom cheeks dekhkar main apna saara kaam bhool gaya. Aaj bhi mere glass frame ke andar wo coffee ke daag wala portrait hai.',
      imageUrl: 'https://picsum.photos/seed/latte/600/400',
      category: 'First Met'
    },
    {
      id: 'm-2',
      date: '2025-05-14',
      title: 'Car Ki Chhat Par Sunrise Dekhna',
      text: 'Yaad hai subah 3 baje mountains mein driving karna? Bahut thand thi, aur hum ek hi flannel blanket ke niche huddle kar ke warm mist nikalte hue Venus ko subah ki dhoop mein ghulte dekh rahe the.',
      imageUrl: 'https://picsum.photos/seed/sunrisesky/600/400',
      category: 'Special Date'
    },
    {
      id: 'm-3',
      date: '2025-10-09',
      title: 'Monstera Plant Ko Adopt Karna',
      text: 'Sath mein chhota sa Monstera plant kharida tha aur lagbhag teen ghante bahes ki thi ki iska naam "Finley" hona chahiye ya "Barnaby." Wo hamare messy room mein bhi survive kar gaya aur teen sundar nayi leaves de dhi!',
      imageUrl: 'https://picsum.photos/seed/greenhome/600/400',
      category: 'Sweet Moments'
    }
  ],
  quizQuestions: [
    {
      id: 'q-1',
      question: 'Hamari pehli meeting par Priya ne mere upar kya giraya tha?',
      options: ['Spicy Chai Latte', 'Cinnamon Latte', 'Classic Iced Matcha'],
      correctAnswerIndex: 1,
      messageIfCorrect: 'Bilkul sahi! Aaj bhi us sketch se sweet cinnamon ki halki fragrance aati hai.',
      messageIfWrong: 'Aray close! Par wo Cinnamon Latte thi. Koi nahi, tum jahan bhi jati ho mithaash phelati ho!'
    },
    {
      id: 'q-2',
      question: 'Humein hamare pyaare Monstera plant ka kya naam rkha tha?',
      options: ['Barnaby', 'Finley', 'Sir Leafington III'],
      correctAnswerIndex: 1,
      messageIfCorrect: 'Haan, Finley! Ab wo khidki ke paas dhoop se energy leta hai.',
      messageIfWrong: 'Hum use Finley bolte hain! Uska naya leaf abhi nikal raha hai!'
    }
  ],
  starWishes: [
    "Sath mein baith kar barish dekhne ke liye ek pyari si glass roof wali cabin.",
    "Tumhari ye pyaari smile hamesha aisi hi chamakti rahe aur kabhi kam na ho.",
    "Agli thand mein Paris ki sadkon par sath ghumte hue roasted chestnuts khayein.",
    "Tum roz subah is yakeen ke sath utho ki tum mere liye sabse zyaada keemti ho.",
    "Plants ke naamo par bahes karna aur matching cups mein latte peena kabhi band na ho."
  ],
  jarNotes: [
    "Main ab bhi apna phone check karta hoon ki tumhara message aaya hoga.",
    "Tumhari pyaari hansi is puri galaxy ka mera sabse pasandida music track hai.",
    "Mujhe bahut pasand hai jab hum dono hamesha exact ek hi word sath bolte hain.",
    "Tumhara haath pakadna hamesha mujhe sukoon deta hai jab life pareshan karti hai.",
    "Tum ek simple Ramen date ko bhi ek bahut pyari indie movie scene bana deti ho.",
    "Happy Birthday, meri pyari star. Ye universe sach mein blessed hai ki tum isme ho."
  ]
};

export default function App() {
  const [settings, setSettings] = useState<SurpriseSettings>(DEFAULT_SETTINGS);
  const [isUnlocked, setIsUnlocked] = useState(false);
  const [passcodeInput, setPasscodeInput] = useState('');
  const [passcodeError, setPasscodeError] = useState(false);

  const [activeTab, setActiveTab] = useState<'timeline' | 'stars' | 'quiz' | 'ai-lab'>('timeline');
  const [daysCount, setDaysCount] = useState<number>(0);
  const [timeRemaining, setTimeRemaining] = useState({ hours: 0, minutes: 0, seconds: 0 });

  // Load custom configuration if it exists
  useEffect(() => {
    const cached = localStorage.getItem('aura_surprise_settings_v1');
    if (cached) {
      try {
        setSettings(JSON.parse(cached));
      } catch (e) {
        console.error("Cached restore error:", e);
      }
    }
  }, []);

  // Update Settings handler
  const handleUpdateSettings = (newSettings: SurpriseSettings) => {
    setSettings(newSettings);
    localStorage.setItem('aura_surprise_settings_v1', JSON.stringify(newSettings));
  };

  const handleFactoryReset = () => {
    if (confirm("Reset everything back to Charlotte's romantic default template?")) {
      setSettings(DEFAULT_SETTINGS);
      localStorage.removeItem('aura_surprise_settings_v1');
    }
  };

  // Days Count up timer
  useEffect(() => {
    const updateTime = () => {
      const start = new Date(settings.anniversaryDate).getTime();
      const current = new Date().getTime();
      const diff = current - start;
      const days = Math.floor(diff / (1000 * 60 * 60 * 24));
      setDaysCount(days);

      // Simple relative hourly countdown for birthday
      const nextHour = new Date();
      nextHour.setHours(24, 0, 0, 0); // Midnight
      const diffTime = nextHour.getTime() - current;
      const hours = Math.floor((diffTime / (1000 * 60 * 60)) % 24);
      const minutes = Math.floor((diffTime / (1000 * 60)) % 60);
      const seconds = Math.floor((diffTime / 1000) % 65);
      setTimeRemaining({ hours, minutes, seconds });
    };

    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, [settings.anniversaryDate]);

  const handleUnlockSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (passcodeInput.trim() === settings.secretPasscode) {
      setIsUnlocked(true);
      setPasscodeError(false);
    } else {
      setPasscodeError(true);
    }
  };

  // Category styles dictionary
  const themeAccentColors: Record<ThemePalette, string> = {
    'rose-romance': 'bg-rose-500 hover:bg-rose-600 text-rose-500 border-rose-200 bg-rose-50/10 hover:text-rose-600',
    'celestial-indigo': 'bg-indigo-600 hover:bg-indigo-700 text-indigo-500 border-indigo-200 bg-indigo-50/10 hover:text-indigo-600',
    'emerald-serenade': 'bg-emerald-600 hover:bg-emerald-700 text-emerald-650 border-emerald-200 bg-emerald-50/10 hover:text-emerald-700',
    'vintage-parchment': 'bg-amber-600 hover:bg-amber-700 text-amber-700 border-amber-200 bg-amber-50/10 hover:text-amber-800'
  };

  const themeBorderClasses: Record<ThemePalette, string> = {
    'rose-romance': 'border-rose-100 dark:border-zinc-800 focus:ring-rose-400 focus:border-rose-400',
    'celestial-indigo': 'border-indigo-100 dark:border-zinc-800 focus:ring-indigo-400 focus:border-indigo-400',
    'emerald-serenade': 'border-emerald-100 dark:border-zinc-800 focus:ring-emerald-400 focus:border-emerald-400',
    'vintage-parchment': 'border-amber-100 dark:border-zinc-800 focus:ring-amber-400 focus:border-amber-400'
  };

  const currentAccent = themeAccentColors[settings.palette];
  const activeBorder = themeBorderClasses[settings.palette];

  return (
    <div className="min-h-screen bg-dark-bg text-warm-white transition-colors duration-300 select-none pb-20 relative">
      
      {/* 1. SECURE PASSCODE GATE / SLIDING WAX SEAL */}
      {!isUnlocked ? (
        <div id="wax-seal-gate" className="fixed inset-0 bg-dark-bg flex flex-col items-center justify-center p-4 z-50">
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-gold/5 via-transparent to-transparent pointer-events-none" />
          
          {/* Ambient atmosphere glow */}
          <div className="absolute top-[-20%] left-[-10%] w-[500px] h-[500px] bg-rose-950/10 rounded-full blur-[100px] pointer-events-none" />
          <div className="absolute bottom-[-10%] right-[-10%] w-[500px] h-[500px] bg-red-950/20 rounded-full blur-[100px] pointer-events-none" />

          <div className="bg-dark-card border border-white/5 p-8 md:p-12 rounded-3xl shadow-2xl max-w-md w-full text-center relative overflow-hidden animate-scale-up">
            
            {/* Sealed Mail Box Icon */}
            <div className="w-16 h-16 bg-[#1a1212] rounded-2xl flex items-center justify-center mx-auto mb-6 border border-gold/15">
              <Mail className="w-8 h-8 text-gold fill-gold/10 animate-pulse" />
            </div>

            <h1 className="font-serif font-bold text-2xl text-warm-white mb-2 leading-tight">
              Ek Pyaara Secret Surprise Tumhara Wait Kar Raha Hai
            </h1>
            <p className="text-xs text-warm-gray max-w-sm mx-auto mb-8">
              Hey {settings.partnerName || 'Pyaar'}! Maine tumhare birthday ke liye ek khubsoorat romantic surprise capsule banaya hai. Isey hamari secret anniversary ya special date se unlock karo!
            </p>

            <form onSubmit={handleUnlockSubmit} className="space-y-4">
              <div>
                <label className="text-[10px] font-mono tracking-wider text-warm-gray block mb-1.5 uppercase font-bold">Hamara Secret Date Code (DDMM)</label>
                <div className="relative">
                  <span className="absolute inset-y-0 left-3 flex items-center text-warm-gray">
                    <Lock className="w-4 h-4" />
                  </span>
                  <input
                    id="gate-code-input"
                    type="password"
                    required
                    placeholder="Enter Secret Code (jaise 0603)"
                    value={passcodeInput}
                    onChange={(e) => setPasscodeInput(e.target.value)}
                    className="w-full pl-10 pr-4 py-3 rounded-xl border border-white/5 bg-zinc-950 text-center text-sm focus:border-gold text-warm-white outline-none placeholder:text-zinc-600"
                  />
                </div>
              </div>

              {passcodeError && (
                <div id="gate-pass-error" className="text-xs text-rose-400 font-semibold flex items-center gap-1.5 justify-center animate-bounce">
                  <AlertCircle className="w-3.5 h-3.5" />
                  <span>Oho, ye code sahi nahi hai. Sitare isey accept nahi kar rahe!</span>
                </div>
              )}

              <button
                id="unlock-surprise-btn"
                type="submit"
                className="w-full py-3 bg-gold hover:bg-gold/95 text-dark-bg rounded-xl text-xs font-semibold shadow-sm focus:outline-none transition-transform active:scale-95 cursor-pointer font-sans tracking-widest uppercase"
              >
                Surprise Box Unlock Karo
              </button>
            </form>

            <div className="mt-8 pt-6 border-t border-white/5 flex flex-col gap-2">
              <button
                id="preview-guest-btn"
                onClick={() => setIsUnlocked(true)}
                className="text-[11px] text-warm-gray hover:text-gold transition-colors block italic"
                title="Bypass passcode screen to review features directly"
              >
                Direct Preview / Designer Mode
              </button>
              <span className="text-[9px] font-mono text-zinc-500">Default key: 0603 (June 3 represents her birthday today!)</span>
            </div>
          </div>
        </div>
      ) : (
        /* 2. THE MAIN CELESTIAL AMOUR SURPRISE CONTENT */
        <div id="surprises-unlocked-canvas" className="animate-fade-in relative z-10 w-full">
          
          {/* Top greeting notification bar */}
          <div className="bg-dark-card border-b border-white/5 text-gold text-xs py-2 text-center flex items-center justify-center gap-2 px-4 shadow-sm relative z-20">
            <Sparkles className="w-3.5 h-3.5 text-gold animate-bounce" />
            <span className="font-mono tracking-wider uppercase text-[10px]">🎉 Magical Alignment Active: Aaj June 3 hai, yaani Priya ka Happy Birthday! 💖</span>
          </div>

          {/* Decorative atmospheric background elements */}
          <div className="absolute top-0 left-0 w-full h-[600px] overflow-hidden pointer-events-none z-0">
            <div className="absolute top-[-20%] left-[-10%] w-[600px] h-[600px] bg-rose-950/15 rounded-full blur-[120px]"></div>
            <div className="absolute bottom-[20%] right-[-10%] w-[600px] h-[600px] bg-red-900/10 rounded-full blur-[120px]"></div>
          </div>

          <nav className="max-w-6xl mx-auto flex justify-between items-center px-6 py-6 relative z-10 border-b border-white/5">
            <div className="text-[10px] tracking-[0.4em] uppercase font-mono font-bold text-gold">Est. Nov 2024</div>
            <div className="hidden md:flex space-x-12 text-warm-gray">
              <span className="text-[10px] tracking-[0.2em] uppercase cursor-pointer hover:text-gold transition-colors" onClick={() => setActiveTab('timeline')}>Humari Kahani</span>
              <span className="text-[10px] tracking-[0.2em] uppercase cursor-pointer hover:text-gold transition-colors" onClick={() => setActiveTab('stars')}>Mannat Ke Taare</span>
              <span className="text-[10px] tracking-[0.2em] uppercase cursor-pointer hover:text-gold transition-colors" onClick={() => setActiveTab('quiz')}>Pyaara Quiz</span>
            </div>
            <div className="text-[10px] tracking-[0.4em] uppercase font-mono font-bold text-warm-gray">Vol. II</div>
          </nav>

          <header className="relative py-20 text-center bg-gradient-to-b from-[#110d0d] to-dark-bg border-b border-white/5 overflow-hidden mb-12 z-10">
            <div className="max-w-4xl mx-auto px-4 flex flex-col items-center">
              <span className="text-[11px] font-mono tracking-[0.3em] text-gold uppercase font-bold flex justify-center items-center gap-2 mb-4">
                <Heart className="w-3.5 h-3.5 text-zinc-550 fill-gold/50 animate-pulse" />
                Mere Hamsafar Ke Liye: Happy Birthday
              </span>

              <h1 className="font-serif text-4xl md:text-7xl font-light text-warm-white italic tracking-tight mb-6">
                {settings.customTitle || 'Happy Birthday, Charlotte'}
              </h1>
              
              <div className="w-20 h-px bg-gold/5s my-4" />

              <p className="text-sm font-sans text-warm-gray font-light max-w-md mx-auto mb-8 tracking-wide leading-relaxed">
                Hamare sath ka ek aur khubsoorat saal. Har ek lamha jo humne sath bitaaya, wo kisi haseen khwaab se kam nahi hai.
              </p>

              {/* Relationship Countdown stats */}
              <div className="inline-flex flex-wrap items-center justify-center gap-6 p-4 rounded-2xl bg-dark-card border border-white/5 shadow-inner mt-4">
                <div className="text-center px-6 border-r border-white/5 last:border-0">
                  <span className="text-3xl font-light font-serif text-gold block">
                    {daysCount >= 0 ? daysCount : 0}
                  </span>
                  <span className="text-[9px] uppercase font-mono tracking-wider text-warm-gray block mt-1">Sath Ke Din</span>
                </div>
                <div className="text-center px-6 last:border-0">
                  <span className="text-base font-mono font-bold text-warm-white block flex items-center justify-center gap-1.5">
                    <Clock className="w-4 h-4 text-gold/80" />
                    {String(timeRemaining.hours).padStart(2, '0')}:{String(timeRemaining.minutes).padStart(2, '0')}:{String(timeRemaining.seconds).padStart(2, '0')}
                  </span>
                  <span className="text-[9px] uppercase font-mono tracking-wider text-warm-gray block mt-1">Agle Din Ka Countdown</span>
                </div>
              </div>
            </div>
          </header>

          <main className="max-w-6xl mx-auto px-4">
            
            {/* BENTO MATRIX GRID FOR ROMANTIC CHANNELS */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-start mb-16">
              
              {/* Left Column: Media & Confession utilities */}
              <div className="lg:col-span-1 space-y-8">
                {/* 1. Synth melody composer */}
                <AudioSynthesizer />

                {/* 2. Confession wish shaker Jar */}
                <HeartWishJar notes={settings.jarNotes} />
              </div>

              {/* Middle & Right: Dynamic Navigation Tab Layout content */}
              <div className="lg:col-span-2 space-y-8">
                
                {/* Rounded beautiful tab selectors */}
                <div className="flex bg-dark-card p-1.5 rounded-2xl border border-white/5 shadow-md gap-2">
                  <button
                    id="tab-btn-timeline"
                    onClick={() => setActiveTab('timeline')}
                    className={`flex-1 py-3 text-xs font-bold rounded-xl flex items-center justify-center gap-1.5 cursor-pointer transition-all duration-300 ${
                       activeTab === 'timeline'
                        ? 'bg-gold text-dark-bg shadow-md'
                        : 'text-warm-gray hover:text-gold hover:bg-white/5'
                    }`}
                  >
                    <Calendar className="w-3.5 h-3.5" />
                    Haseen Yaadein
                  </button>
                  <button
                    id="tab-btn-stars"
                    onClick={() => setActiveTab('stars')}
                    className={`flex-1 py-3 text-xs font-bold rounded-xl flex items-center justify-center gap-1.5 cursor-pointer transition-all duration-300 ${
                       activeTab === 'stars'
                        ? 'bg-gold text-dark-bg shadow-md'
                        : 'text-warm-gray hover:text-gold hover:bg-white/5'
                    }`}
                  >
                    <Compass className="w-3.5 h-3.5" />
                    Mannat Ke Taare
                  </button>
                  <button
                    id="tab-btn-quiz"
                    onClick={() => setActiveTab('quiz')}
                    className={`flex-1 py-3 text-xs font-bold rounded-xl flex items-center justify-center gap-1.5 cursor-pointer transition-all duration-300 ${
                       activeTab === 'quiz'
                        ? 'bg-gold text-dark-bg shadow-md'
                        : 'text-warm-gray hover:text-gold hover:bg-white/5'
                    }`}
                  >
                    <Heart className="w-3.5 h-3.5" />
                    Pyaar Bhara Quiz
                  </button>
                  <button
                    id="tab-btn-ailab"
                    onClick={() => setActiveTab('ai-lab')}
                    className={`flex-1 py-3 text-xs font-bold rounded-xl flex items-center justify-center gap-1.5 cursor-pointer transition-all duration-300 ${
                       activeTab === 'ai-lab'
                        ? 'bg-gold text-dark-bg shadow-md'
                        : 'text-warm-gray hover:text-gold hover:bg-white/5'
                    }`}
                  >
                    <Sparkles className="w-3.5 h-3.5 text-amber-500 fill-amber-500/20" />
                    Gemini AI Lab
                  </button>
                </div>

                {/* Tab content screens */}
                <div id="tab-screen-box" className="transition-all duration-300">
                  {activeTab === 'timeline' && (
                    <div className="animate-fade-in">
                      <MemoryLane
                        memories={settings.memories}
                        onAddMemory={(newM) => {
                          const updatedArgs: LoveMemory = {
                            ...newM,
                            id: `m-${Date.now()}`
                          };
                          handleUpdateSettings({
                            ...settings,
                            memories: [...settings.memories, updatedArgs]
                          });
                        }}
                      />
                    </div>
                  )}

                  {activeTab === 'stars' && (
                    <div className="animate-fade-in space-y-4">
                      <StargazingCanvas wishes={settings.starWishes} />
                    </div>
                  )}

                  {activeTab === 'quiz' && (
                    <div className="animate-fade-in">
                      <InteractiveQuiz
                        questions={settings.quizQuestions}
                        partnerName={settings.partnerName}
                      />
                    </div>
                  )}

                  {activeTab === 'ai-lab' && (
                    <div className="animate-fade-in">
                      <AiLoveLab
                        partnerName={settings.partnerName}
                        anniversaryDate={settings.anniversaryDate}
                      />
                    </div>
                  )}
                </div>

              </div>

            </div>

            {/* 3. THE LIVE NO-CODE SURPRISE CONFIGURATION DESK */}
            <div className="border-t border-zinc-200 dark:border-zinc-800 pt-12 pb-16">
              <LoveArchitectDashboard
                settings={settings}
                onUpdateSettings={handleUpdateSettings}
                onFactoryReset={handleFactoryReset}
              />
            </div>

          </main>
        </div>
      )}
    </div>
  );
}
