import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// Lazy-initialize Gemini client
let aiClient: GoogleGenAI | null = null;
function getGeminiClient() {
  if (!aiClient) {
    const apiKey = process.env.GEMINI_API_KEY;
    if (apiKey && apiKey !== "MY_GEMINI_API_KEY" && apiKey.trim() !== "") {
      try {
        aiClient = new GoogleGenAI({
          apiKey: apiKey.trim(),
          httpOptions: {
            headers: {
              'User-Agent': 'aistudio-build',
            }
          }
        });
      } catch (err) {
        console.error("Failed to initialize Gemini AI client:", err);
      }
    }
  }
  return aiClient;
}

// 1. API: Generate Romanitc Birthday Poem
app.post("/api/generate/poem", async (req, res) => {
  const { partnerName, tone, quirks, anniversaryDate } = req.body;
  const client = getGeminiClient();

  // Premium romantic backups in case Gemini API is not configured or fails
  const fallbackPoem = `Meri pyaari ${partnerName || 'Priya'},\n\nTumahre sath bitaya har lamha ek pyaara khwaab hai,\nSitaron se bhara aasmaan aur dhoop ki mithaas hai.\nTumhari hansi meri sabse pasandida bhun aur sangeet hai,\nMera dil hamesha tumhare kareeb aur tumhare hi geet hai.\n\nTumhare is Birthday par, mera dil pyaar se bhar gaya hai,\nHar behti hava ke sath ye aur gehra ho gaya hai.\nMain tumse kal bhi pyaar karta tha, aaj bhi aur hamesha karta rahunga,\nTumhare is masoom chehre par hamesha fida rahunga.`;

  if (!client) {
    return res.json({
      text: fallbackPoem,
      isFallback: true,
      message: "Using pre-crafted high-fidelity romance engine (add your GEMINI_API_KEY for dynamic custom compositions!)"
    });
  }

  try {
    const prompt = `Write a deeply emotional, highly personalized romantic birthday rhyming poem.
    - Name of Partner: "${partnerName || 'My Beloved'}"
    - Tone: "${tone || 'emotional-deep, nostalgic, beautiful'}"
    - Cute Habits/Quirks to mention: "${quirks || 'smiling brighter than the stars'}"
    - Anniversary Date/Context: "${anniversaryDate || 'our special bond'}"
    
    CRITICAL: Write the poem entirely in conversational Hindustani/Hinglish (Hindi words written using English alphabet script). Keep it natural, sweet, poetic, and heartwarming.
    Structure it beautifully in stanzas.`;

    const response = await client.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        temperature: 0.85,
        systemInstruction: "You are a world-class romantic poet. You write sweet, deep, non-cheesy romantic lyrics, letters, and alignment reports entirely in Hinglish (Hindi written in Latin/English script) using conversational, sweet, and warm words (like 'pyaar', 'hansi', 'dil', 'sath', 'khwahish'). Ensure the output is natural Hinglish that young South Asian couples use to speak to each other."
      }
    });

    res.json({
      text: response.text ? response.text : fallbackPoem,
      isFallback: false
    });
  } catch (error: any) {
    console.error("Gemini Poetry Generation failed:", error);
    res.json({
      text: fallbackPoem,
      isFallback: true,
      message: `Failed to connect with celestial Gemini nodes. Enjoying our timeless prose.`
    });
  }
});

// 2. API: Generate Intimate Birthday Love Letter
app.post("/api/generate/letter", async (req, res) => {
  const { partnerName, senderName, favoriteMemory, relationshipLength, toneStyle } = req.body;
  const client = getGeminiClient();

  const fallbackLetter = `Meri pyaari ${partnerName || 'Pyaar'},\n\nHappy Birthday usko jisne meri puri zindagi ko sunehra aur khubsoorat bana diya hai. Hamare in guzaare hue ${relationshipLength || 'haseen mahino / saalon'} ko jab main mudkar dekhta hoon, toh lagta hai ki tumhare aane se meri duniya hi badal gayi. Hamari sabse achhi yaadon mein se ek wo hai jab humne sath mein ${favoriteMemory || 'cozy lamhe share kiye the'}.\n\nTumhara pyaara dil, tumhari smile, aur wo choti-choti masoom baatein mujhe roj fir se tumhare pyaar mein gira deti hain. Tumhare birthday par meri bas yahi khwahish hai ki hum hamesha aise hi ek doosre ka haath pakad kar late-night haste rahein aur zindagi ka har lamha sath bitayein.\n\nHamesha tumhara,\n${senderName || 'Tumhara Pyaar'}`;

  if (!client) {
    return res.json({
      text: fallbackLetter,
      isFallback: true,
      message: "Using cozy romantic stationery fallback (add your GEMINI_API_KEY in Secrets for live customizable letters!)"
    });
  }

  try {
    const prompt = `Compose a beautifully structured, highly romantic, and deeply emotional birthday love letter.
    - To: "${partnerName}"
    - From: "${senderName}"
    - Time together: "${relationshipLength || 'our timeless journey'}"
    - A key sweet memory to weave in: "${favoriteMemory || 'just talking under the stars'}"
    - Style/Vibe: "${toneStyle || 'cosmic-romantic, glowing, timeless, gentle'}"

    CRITICAL: Write the letter entirely in natural, sweet conversational Hinglish (Hindi written in Latin script). Keep it touchingly beautiful and genuine. Use paragraphs elegantly.`;

    const response = await client.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        temperature: 0.9,
        systemInstruction: "You are a world-classic and highly romantic love letter writer. You compose deep, elegant, non-cheesy letters entirely in modern natural Hinglish (conversational Hindi using the English/Latin alphabet) that touches the heart deeply. Make it beautiful, emotional, and unforgettable."
      }
    });

    res.json({
      text: response.text ? response.text : fallbackLetter,
      isFallback: false
    });
  } catch (err) {
    console.error("Gemini Love Letter Generation failed:", err);
    res.json({
      text: fallbackLetter,
      isFallback: true
    });
  }
});

// 3. API: Destiny Alignment Calculator
app.post("/api/generate/alignment", async (req, res) => {
  const { signA, signB, activitiesA, activitiesB } = req.body;
  const client = getGeminiClient();

  const fallbackAlignment = `✨ Sitaron Ka Milan Result: 98% (Adhbhut Jodi!) ✨\n\nAapki rashi aur jeevan dasha kehti hai ki aap dono ek doosre ke liye hi bane hain. Hamare feelings aur vibes ekdum perfect resonance mein hain. Sath ghumna, naye sapne dekhna aur ek doosre ka khayal rakhna aapke is rishte ko aur bhi sunehra banata hai. Sitaron ki ye alignment hamesha aapke sath hai!`;

  if (!client) {
    return res.json({
      text: fallbackAlignment,
      isFallback: true
    });
  }

  try {
    const prompt = `Perform a magical, deeply sweet, and celestial love alignment analytics report.
    - Person A Details: Zodiac "${signA || 'Unknown'}", and loves "${activitiesA || 'chasing dreams'}"
    - Person B Details: Zodiac "${signB || 'Unknown'}", and loves "${activitiesB || 'beautiful stargazing'}"

    CRITICAL: Write the cosmic compatibility report entirely in conversational Hinglish (Hindi written using English/Latin alphabet). Provide an explicit alignment percentage (e.g., 96% to 99.9%) and delightful descriptions of their chemistry. Keep it incredibly sweet and starry.`;

    const response = await client.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        temperature: 0.95,
        systemInstruction: "You are an ultimate classic Vedic and western astrologer with a high romantic lens. Write alignment results uniquely in natural, romantic conversational Hinglish (conversational Hindi using the Latin script)."
      }
    });

    res.json({
      text: response.text ? response.text : fallbackAlignment,
      isFallback: false
    });
  } catch (err) {
    res.json({
      text: fallbackAlignment,
      isFallback: true
    });
  }
});

async function start() {
  // Serve frontend assets
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[Aura Full-Stack Engine] booted successfully on port ${PORT}`);
  });
}

start();
